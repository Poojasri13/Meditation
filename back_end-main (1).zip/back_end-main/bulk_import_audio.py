# bulk_import_audio.py
import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myproject.settings")
django.setup()

from user.models import AudioTrack

# ------- 5 modules × 5 descriptions --------
DESCRIPTIONS = {
    "m-1": [
        "Build focus through slow breath awareness and gentle returning to the breath.",
        "Use breath counting to reduce mind-wandering and improve concentration.",
        "Strengthen focus by observing the breath in different parts of the body.",
        "Deepen attention by staying with the breath and returning calmly from distraction.",
        "Practice whole-body breathing to develop steady and continuous focus.",
    ],
    "m-2": [
        "Visualize simple objects to strengthen mental holding and clarity.",
        "Use shapes and rotations to improve mental tracking and memory.",
        "Follow drifting objects to enhance working memory and attention control.",
        "Hold multiple glowing orbs in mind to build memory stability.",
        "Visualize number sequences to improve short-term memory and recall.",
    ],
    "m-3": [
        "Use a body scan to notice and regulate emotional sensations.",
        "Label a mild emotion to reduce reactivity and increase clarity.",
        "Visualize emotions as shapes to observe them with distance and calm.",
        "Notice and name emotions gently to bring balance and ease.",
        "Visualize emotions as soft light to support emotional softness and clarity.",
    ],
    "m-4": [
        "Ground yourself using the five senses to stay fully present.",
        "Tune into breath and body sensations to deepen present awareness.",
        "Strengthen presence by noticing sounds, temperature, and subtle sensations.",
        "Use breath and sensory awareness to stay grounded in the moment.",
        "Experience the present by combining breath, body, and environmental awareness.",
    ],
    "m-5": [
        "Observe thoughts and sensations openly to improve mental flexibility.",
        "Shift attention between breath, sound, and sensation to train adaptability.",
        "Practice wide awareness by letting attention move freely and smoothly.",
        "Strengthen flexibility by moving awareness across different experiences.",
        "Use open monitoring to stay adaptable as experiences rise and fade.",
    ]
}

MEDIA_PATH = "media/audio"  # keep unchanged


def import_audios(delete_existing=True):
    root = os.getcwd()
    path = os.path.join(root, MEDIA_PATH)

    if not os.path.isdir(path):
        print("❌ Folder not found:", path)
        return

    if delete_existing:
        print("🗑️ Deleting old AudioTracks...")
        AudioTrack.objects.all().delete()
        print("✔️ Deleted.\n")

    files = sorted(os.listdir(path))
    count = 0

    for f in files:
        if not f.lower().endswith(".mp3"):
            continue

        filename = f[:-4]  # remove .mp3

        try:
            module_part, sub_part = filename.split("_")  # m-3 , sub-4
            module = module_part.lower()
            sub_number = int(sub_part.split("-")[1])
        except Exception as e:
            print("❌ Invalid filename:", f, "|", e)
            continue

        # Display title
        title = f"Sub-video {sub_number}"

        # Description
        description = DESCRIPTIONS.get(module, [""] * 5)[sub_number - 1]

        # Save WITHOUT duration
        AudioTrack.objects.create(
            title=title,
            module_type=module,
            file=f"audio/{f}",
            details={
                "description": description
            }
        )

        print("✔️ Imported:", f)
        count += 1

    print(f"\n🎉 Imported {count} audio files successfully.")


if __name__ == "__main__":
    import_audios(delete_existing=True)
