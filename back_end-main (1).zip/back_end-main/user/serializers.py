from rest_framework import serializers
from .models import User, Score, AudioTrack


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            "id", "user_id", "age", "gender", "email", "password",
            "maas_initial", "panas_initial", "dass_initial",
            "erq_initial", "phlms_initial"
        ]
        extra_kwargs = {"password": {"write_only": True}}

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)   # 🔐 HASH HERE
        user.save()
        return user


class ScoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Score
        fields = "__all__"


class AudioTrackSerializer(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()

    class Meta:
        model = AudioTrack
        fields = [
            "id",
            "title",
            "module_type",
            "url",
            "duration_seconds",
            "details",
            "created_at",
        ]
        read_only_fields = ["id", "url", "created_at"]

    def get_url(self, obj):
        request = self.context.get("request")
        if not obj.file:
            return None

        path = obj.file.url.replace(" ", "%20")
        return request.build_absolute_uri(path) if request else path


# -------- PASSWORD RESET --------
class ForgotPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()


class VerifyOtpSerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField(max_length=6)


class ResetPasswordWithOtpSerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField(max_length=6)
    new_password = serializers.CharField(min_length=6)


class MLPredictionSerializer(serializers.Serializer):
    maas = serializers.FloatField()
    panas_pos = serializers.FloatField()
    panas_neg = serializers.FloatField()
    dass = serializers.FloatField()
    erq = serializers.FloatField()
    phlms = serializers.FloatField()
