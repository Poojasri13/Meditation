from django.urls import path
from . import views

urlpatterns = [

    # 🔐 AUTH
    path('signup/', views.signup),
    path('login/', views.login_view),
    path('profile/<str:email>/', views.get_profile),
    path('update-profile/', views.update_profile),

    # 🧠 PRE QUESTIONNAIRES
    path('save-maas-pre/', views.save_maas_pre),
    path('save-panas-pre/', views.save_panas_pre),
    path('save-dass-pre/', views.save_dass_pre),
    path('save-erq-pre/', views.save_erq_pre),
    path('save-phlms-pre/', views.save_phlms_pre),
    path('save-cfq-pre/', views.save_cfq_pre),

    # 🚀 TASK SCORES
    path('save-cfq-post/', views.save_cfq_post),
    path('save-srt-post/', views.save_srt_post),
    path('save-nback-post/', views.save_nback_post),
    path('save-stroop-post/', views.save_stroop_post),
    path('save-task-switch-post/', views.save_task_switch_post),
    path('save-sart-post/', views.save_sart_post),

    # 📊 SCORES
    path('scores/<str:email>/', views.get_scores),

    # 🎧 AUDIO
    path('audios/', views.list_audios),
    path('upload-audio/', views.upload_audio),
    path('sync-audios/', views.sync_audios_from_disk),

    # 🔐 OTP
    path("send-otp/", views.send_otp),
    path("verify-otp/", views.verify_otp),
    path("reset-password/", views.reset_password),

    # 🧠 ML
    path("predict/", views.predict_mental_state),
]
