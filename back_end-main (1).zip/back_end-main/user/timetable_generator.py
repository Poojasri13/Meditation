import random
from collections import defaultdict
from user.models import AudioTrack

TOTAL_DAYS = 21

LABEL_TO_MODULES = {
    "focus": ["m-1", "m-2"],
    "emotion_regulation": ["m-3"],
    "stress": ["m-4"],
    "anxiety": ["m-5"],
}

ALL_LABELS = ["focus", "emotion_regulation", "stress", "anxiety"]


def generate_timetable(selected_labels):
    if not selected_labels:
        return []

    # --------------------------------------------------
    # 1️⃣ Build probability map with fallback
    # --------------------------------------------------
    prob_map = {l: 0.0 for l in ALL_LABELS}

    for item in selected_labels:
        prob_map[item["label"]] = item["probability"]

    active = [l for l, p in prob_map.items() if p > 0]

    # If only one label → soften dominance
    if len(active) == 1:
        dominant = active[0]
        prob_map[dominant] = 0.45

        others = [l for l in ALL_LABELS if l != dominant]
        share = 0.55 / len(others)
        for l in others:
            prob_map[l] = share

    # Normalize
    total = sum(prob_map.values())
    for l in prob_map:
        prob_map[l] /= total

    # --------------------------------------------------
    # 2️⃣ Allocate days per label
    # --------------------------------------------------
    label_days = {}
    allocated = 0

    for label, weight in prob_map.items():
        days = max(1, round(weight * TOTAL_DAYS))
        label_days[label] = days
        allocated += days

    # Fix rounding
    while allocated > TOTAL_DAYS:
        k = max(label_days, key=label_days.get)
        label_days[k] -= 1
        allocated -= 1

    while allocated < TOTAL_DAYS:
        k = max(label_days, key=label_days.get)
        label_days[k] += 1
        allocated += 1

    # --------------------------------------------------
    # 3️⃣ Load audios per module
    # --------------------------------------------------
    module_audio_map = {}
    for label in ALL_LABELS:
        for module in LABEL_TO_MODULES[label]:
            audios = list(AudioTrack.objects.filter(module_type=module))
            random.shuffle(audios)
            module_audio_map[module] = audios

    # --------------------------------------------------
    # 4️⃣ Build timetable (ALLOW REUSE AFTER EXHAUSTION)
    # --------------------------------------------------
    timetable = []
    module_pointers = defaultdict(int)
    last_audio_id = None

    while len(timetable) < TOTAL_DAYS:
        progress = False

        for label, remaining in label_days.items():
            if remaining <= 0:
                continue

            for module in LABEL_TO_MODULES[label]:
                audios = module_audio_map[module]

                if not audios:
                    continue

                idx = module_pointers[module] % len(audios)
                audio = audios[idx]
                module_pointers[module] += 1

                # ❌ Avoid same audio consecutively
                if audio.id == last_audio_id:
                    continue

                timetable.append({
                    "audio_code": audio.file.name.replace("audio/", "").replace(".mp3", ""),
                    "module": module,
                    "title": audio.title,
                    "description": audio.details.get("description", "")
                })

                last_audio_id = audio.id
                label_days[label] -= 1
                progress = True

                if len(timetable) >= TOTAL_DAYS:
                    break

        # Safety: if no progress, allow reuse ignoring last constraint
        if not progress:
            for module, audios in module_audio_map.items():
                if audios:
                    audio = random.choice(audios)
                    timetable.append({
                        "audio_code": audio.file.name.replace("audio/", "").replace(".mp3", ""),
                        "module": module,
                        "title": audio.title,
                        "description": audio.details.get("description", "")
                    })
                    last_audio_id = audio.id
                    break

    return timetable[:TOTAL_DAYS]
