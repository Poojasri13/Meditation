def select_labels(probabilities):
    """
    probabilities: dict {label: probability}

    returns:
    [
        {
            "label": "stress",
            "probability": 0.981,
            "level": "high"
        },
        ...
    ]
    """

    selected = []

    for label, score in probabilities.items():
        if score >= 0.80:
            selected.append({
                "label": label,
                "probability": round(score, 3),
                "level": "high"
            })
        elif score >= 0.60:
            selected.append({
                "label": label,
                "probability": round(score, 3),
                "level": "medium"
            })

    return selected
