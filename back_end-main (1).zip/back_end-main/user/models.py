from django.db import models
from django.contrib.auth.hashers import make_password, check_password
from django.utils import timezone
from mutagen import File as MutagenFile
import random


# ------------------- USER MODEL -------------------
class User(models.Model):
    user_id = models.CharField(max_length=100)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)

    maas_initial = models.IntegerField(null=True, blank=True)
    panas_initial = models.IntegerField(null=True, blank=True)
    dass_initial = models.IntegerField(null=True, blank=True)
    erq_initial = models.IntegerField(null=True, blank=True)
    phlms_initial = models.IntegerField(null=True, blank=True)

    # OTP RESET
    reset_otp = models.CharField(max_length=6, null=True, blank=True)
    reset_otp_created = models.DateTimeField(null=True, blank=True)

    # 🔐 PASSWORD HANDLING (CORRECT)
    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def generate_otp(self):
        otp = str(random.randint(100000, 999999))
        self.reset_otp = otp
        self.reset_otp_created = timezone.now()
        self.save(update_fields=["reset_otp", "reset_otp_created"])
        return otp

    def __str__(self):
        return self.email


# ------------------- SCORE MODEL -------------------
class Score(models.Model):
    DOMAIN_CHOICES = [
        ("maas", "MAAS"),
        ("panas", "PANAS"),
        ("dass", "DASS"),
        ("erq", "ERQ"),
        ("phlms", "PHLMS"),
        ("cfq", "CFQ"),
        ("nback", "NBACK"),
        ("srt", "SRT"),
        ("stroop", "STROOP"),
        ("task_switch", "TASK_SWITCH"),
        ("sart", "SART"),
    ]

    TYPE_CHOICES = [
        ("pre", "pre"),
        ("post", "post"),
       
        ("task", "task"),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="scores")
    domain = models.CharField(max_length=32, choices=DOMAIN_CHOICES)
    score = models.FloatField()
    score_type = models.CharField(max_length=16, choices=TYPE_CHOICES)
    details = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class AudioTrack(models.Model):
    title = models.CharField(max_length=200)
    module_type = models.CharField(max_length=50, null=True, blank=True)
    file = models.FileField(upload_to="audio/")
    duration_seconds = models.IntegerField(null=True, blank=True)
    details = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        if self.file and not self.duration_seconds:
            try:
                if hasattr(self.file, "path"):
                    audio = MutagenFile(self.file.path)
                    if audio and audio.info and audio.info.length:
                        self.duration_seconds = int(audio.info.length)
                        super().save(update_fields=["duration_seconds"])
            except Exception:
                # ❌ Do nothing – NEVER crash
                pass