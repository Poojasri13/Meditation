import os
import joblib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "mental_state_model_bundle.pkl")

_model_bundle = None


def load_model():
    global _model_bundle

    if _model_bundle is None:
        if not os.path.exists(MODEL_PATH):
            raise RuntimeError("ML model file not found")

        _model_bundle = joblib.load(MODEL_PATH)

    return _model_bundle


def predict_with_labels(input_df):
    bundle = load_model()

    model = bundle["model"]
    labels = bundle["labels"]
    features = bundle["features"]

    input_df = input_df[features]
    probs = model.predict_proba(input_df)[0]

    return {
        label: round(float(prob), 3)
        for label, prob in zip(labels, probs)
    }
