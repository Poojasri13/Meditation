from django.contrib import admin
from .models import User, Score, AudioTrack

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('email', 'user_id', 'age')

@admin.register(Score)
class ScoreAdmin(admin.ModelAdmin):
    list_display = ('user', 'domain', 'score', 'score_type', 'created_at')
    list_filter = ('domain', 'score_type')

@admin.register(AudioTrack)
class AudioTrackAdmin(admin.ModelAdmin):
    list_display = ('title', 'module_type', 'file', 'duration_seconds', 'created_at')
