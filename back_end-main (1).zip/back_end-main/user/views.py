from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

import pandas as pd
import os
import re
import datetime

from django.conf import settings
from django.core.files import File
from django.core.mail import send_mail
from django.utils import timezone

from .models import User, Score, AudioTrack
from .serializers import (
    UserSerializer,
    ScoreSerializer,
    AudioTrackSerializer,
    ForgotPasswordSerializer,
    VerifyOtpSerializer,
    ResetPasswordWithOtpSerializer,
    MLPredictionSerializer
)

from .label_selector import select_labels
from .timetable_generator import generate_timetable
from .model_loader import predict_with_labels


# =========================================================
# CONSTANTS
# =========================================================
OTP_EXPIRY_MINUTES = 10


# =========================================================
# 🔐 AUTH
# =========================================================
@api_view(["POST"])
def signup(request):
    serializer = UserSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()  # password hashing handled in serializer
        return Response({"message": "User created successfully"}, status=201)
    return Response(serializer.errors, status=400)


@api_view(["POST"])
def login_view(request):
    email = request.data.get("email")
    password = request.data.get("password")

    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({"error": "User not found"}, status=404)

    if not user.check_password(password):
        return Response({"error": "Invalid password"}, status=401)

    return Response({"message": "Login successful"}, status=200)


@api_view(["GET"])
def get_profile(request, email):
    try:
        user = User.objects.get(email=email)
        return Response(UserSerializer(user).data)
    except User.DoesNotExist:
        return Response({"error": "User not found"}, status=404)


@api_view(["POST"])
def update_profile(request):
    email = request.data.get("email")
    name = request.data.get("name")
    age = request.data.get("age")
    gender = request.data.get("gender")

    if not email:
        return Response({"error": "email is required"}, status=400)

    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({"error": "User not found"}, status=404)

    updated_fields = []

    if name is not None:
        user.user_id = name
        updated_fields.append("user_id")

    if age is not None:
        try:
            user.age = int(age)
            updated_fields.append("age")
        except ValueError:
            return Response({"error": "age must be a number"}, status=400)

    if gender is not None:
        user.gender = gender
        updated_fields.append("gender")

    if updated_fields:
        user.save(update_fields=updated_fields)

    return Response({"message": "Profile updated"})


# =========================================================
# 🧠 SCORE HELPERS
# =========================================================
def _save_convenience_score(data, domain, score_type):
    email = data.get("email")
    score = data.get("score")

    if not email or score is None:
        return Response({"error": "email and score required"}, 400)

    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({"error": "User not found"}, 404)

    s = Score.objects.create(
        user=user,
        domain=domain,
        score=float(score),
        score_type=score_type,
        details=data.get("details")
    )

    return Response({"message": "Score saved", "id": s.id}, 201)


# =========================================================
# 🧠 PRE QUESTIONNAIRES
# =========================================================
@api_view(["POST"])
def save_maas_pre(request): return _save_convenience_score(request.data, "maas", "pre")

@api_view(["POST"])
def save_panas_pre(request): return _save_convenience_score(request.data, "panas", "pre")

@api_view(["POST"])
def save_dass_pre(request): return _save_convenience_score(request.data, "dass", "pre")

@api_view(["POST"])
def save_erq_pre(request): return _save_convenience_score(request.data, "erq", "pre")

@api_view(["POST"])
def save_phlms_pre(request): return _save_convenience_score(request.data, "phlms", "pre")

@api_view(["POST"])
def save_cfq_pre(request): return _save_convenience_score(request.data, "cfq", "pre")


# =========================================================
# 🚀 TASK SCORES
# =========================================================
@api_view(["POST"])
def save_cfq_post(request): return _save_convenience_score(request.data, "cfq", "task")

@api_view(["POST"])
def save_srt_post(request): return _save_convenience_score(request.data, "srt", "task")

@api_view(["POST"])
def save_nback_post(request): return _save_convenience_score(request.data, "nback", "task")

@api_view(["POST"])
def save_stroop_post(request): return _save_convenience_score(request.data, "stroop", "task")

@api_view(["POST"])
def save_task_switch_post(request): return _save_convenience_score(request.data, "task_switch", "task")

@api_view(["POST"])
def save_sart_post(request): return _save_convenience_score(request.data, "sart", "task")


# =========================================================
# 📊 GET SCORES
# =========================================================
@api_view(["GET"])
def get_scores(request, email):
    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({"error": "User not found"}, 404)

    domain = request.query_params.get("domain")
    qs = user.scores.all()
    if domain:
        qs = qs.filter(domain=domain)

    return Response(ScoreSerializer(qs, many=True).data)


# =========================================================
# 🎧 AUDIO
# =========================================================
@api_view(["GET"])
def list_audios(request):
    qs = AudioTrack.objects.all().order_by("created_at")
    module = request.query_params.get("module")
    if module:
        qs = qs.filter(module_type=module)

    return Response(AudioTrackSerializer(qs, many=True, context={"request": request}).data)


@api_view(["POST"])
def upload_audio(request):
    if "file" not in request.FILES or not request.data.get("title"):
        return Response({"error": "title + file required"}, 400)

    audio = AudioTrack.objects.create(
        title=request.data["title"],
        module_type=request.data.get("module_type"),
        file=request.FILES["file"]
    )

    return Response(AudioTrackSerializer(audio, context={"request": request}).data, 201)


@api_view(["POST"])
def sync_audios_from_disk(request):
    from mutagen.mp3 import MP3

    audio_dir = os.path.join(settings.MEDIA_ROOT, "audio")
    if not os.path.isdir(audio_dir):
        return Response({"error": "audio folder not found"}, status=404)

    AudioTrack.objects.all().delete()
    imported, skipped = 0, []

    for fname in os.listdir(audio_dir):
        if not fname.lower().endswith(".mp3"):
            continue

        try:
            match = re.search(r"(\d+)", fname)
            if not match:
                raise ValueError("Invalid filename")

            number = int(match.group(1))
            module_type = fname.split("_")[0].lower()
            path = os.path.join(audio_dir, fname)

            meta = MP3(path)
            duration = int(meta.info.length) if meta and meta.info else None

            with open(path, "rb") as f:
                AudioTrack.objects.create(
                    title=f"Sub {number}",
                    module_type=module_type,
                    file=File(f, name=fname),
                    duration_seconds=duration
                )

            imported += 1
        except Exception as e:
            skipped.append({"file": fname, "error": str(e)})

    return Response({"imported": imported, "skipped": skipped})


# =========================================================
# 🔐 OTP PASSWORD RESET
# =========================================================
@api_view(["POST"])
def send_otp(request):
    serializer = ForgotPasswordSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    email = serializer.validated_data["email"]

    try:
        user = User.objects.get(email=email)
        otp = user.generate_otp()

        send_mail(
            "CogniSync Password Reset OTP",
            f"Your OTP is {otp}. Valid for {OTP_EXPIRY_MINUTES} minutes.",
            settings.EMAIL_HOST_USER,
            [email],
            fail_silently=False
        )
    except User.DoesNotExist:
        pass

    return Response({"message": "If account exists, OTP sent"})


@api_view(["POST"])
def verify_otp(request):
    serializer = VerifyOtpSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    email = serializer.validated_data["email"]
    otp = serializer.validated_data["otp"]

    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({"error": "Invalid OTP"}, 400)

    if user.reset_otp != otp:
        return Response({"error": "Invalid OTP"}, 400)

    if user.reset_otp_created < timezone.now() - datetime.timedelta(minutes=OTP_EXPIRY_MINUTES):
        return Response({"error": "OTP expired"}, 400)

    return Response({"message": "OTP verified"})


@api_view(["POST"])
def reset_password(request):
    serializer = ResetPasswordWithOtpSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    email = serializer.validated_data["email"]
    otp = serializer.validated_data["otp"]
    new_password = serializer.validated_data["new_password"]

    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({"error": "Invalid request"}, 400)

    if user.reset_otp != otp:
        return Response({"error": "Invalid OTP"}, 400)

    if user.reset_otp_created < timezone.now() - datetime.timedelta(minutes=OTP_EXPIRY_MINUTES):
        return Response({"error": "OTP expired"}, 400)

    user.set_password(new_password)
    user.reset_otp = None
    user.reset_otp_created = None
    user.save(update_fields=["password", "reset_otp", "reset_otp_created"])

    return Response({"message": "Password updated successfully"})


# =========================================================
# 🧠 ML PREDICT (SAFE)
# =========================================================
@api_view(["POST"])
def predict_mental_state(request):
    serializer = MLPredictionSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=400)

    data = serializer.validated_data

    input_df = pd.DataFrame([{
        "maas": data["maas"],
        "panas_pos": data["panas_pos"],
        "panas_neg": data["panas_neg"],
        "dass": data["dass"],
        "erq": data["erq"],
        "phlms": data["phlms"]
    }])

    try:
        probabilities = predict_with_labels(input_df)
    except RuntimeError:
        return Response({"error": "ML model not available"}, status=500)

    selected_labels = select_labels(probabilities)
    timetable = generate_timetable(selected_labels)

    return Response({
        "probabilities": probabilities,
        "selected_labels": selected_labels,
        "timetable": timetable
    })
