//
//  MeditationApp.swift
//  Meditation
//
//  Created by SAIL on 25/03/26.
//

import SwiftUI
import UserNotifications

@main
struct MeditationApp: App {

    @Environment(\.scenePhase) private var scenePhase

    init() {
        // Request notification permission once at launch
        NotificationManager.shared.requestAuthorization()

        // Allow notifications to show banners even while the app is in foreground
        UNUserNotificationCenter.current().delegate = AppNotificationDelegate.shared
    }

    var body: some Scene {
        WindowGroup {
            AppRootView()
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                // When the app comes to the foreground, check if 24h+ has elapsed
                // since the last task completion and fire the reminder immediately
                // if the system notification hasn't been delivered yet.
                NotificationManager.shared.checkAndDeliverIfOverdue()
            }
        }
    }
}

// MARK: - Foreground Notification Delegate
// Makes notifications appear as banners even when the app is in the foreground.
class AppNotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = AppNotificationDelegate()

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        // Show banner + sound in foreground
        completionHandler([.banner, .sound])
    }
}
