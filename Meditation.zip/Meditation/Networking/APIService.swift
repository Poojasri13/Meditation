import Foundation

// MARK: - APIService (matches Android ApiClient + ApiService)
class APIService {
    static let shared = APIService()
    // Change this to your system IP (e.g. 192.168.x.x) for physical devices.
    // For iOS Simulator on the same Mac, 127.0.0.1 or localhost usually works.
    let baseURL = "http://172.25.87.192/Meditation/"

    private var session: URLSession {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 30
        return URLSession(configuration: config)
    }

    private func url(_ path: String) -> URL {
        URL(string: baseURL + path)!
    }

    // Generic POST — returns (success, errorMessage)
    private func post<T: Encodable>(path: String, body: T, completion: @escaping (Bool, String?) -> Void) {
        print("[APIService] POST to \(path)")
        var req = URLRequest(url: url(path))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONEncoder().encode(body)
        
        session.dataTask(with: req) { data, resp, err in
            if let err = err {
                print("[APIService] NETWORK ERROR: \(err.localizedDescription)")
                DispatchQueue.main.async { completion(false, err.localizedDescription) }
                return
            }
            
            let http = resp as? HTTPURLResponse
            let statusCode = http?.statusCode ?? -1
            var ok = (200...299).contains(statusCode)
            
            var errorMessage: String? = nil
            
            if let data = data {
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let status = json["status"] as? String, status == "error" {
                        ok = false
                        errorMessage = json["message"] as? String ?? json["sql_error"] as? String ?? "Server reported an error"
                    }
                } else if let raw = String(data: data, encoding: .utf8) {
                    print("[APIService] [\(path)] RAW RESPONSE: \(raw)")
                    if !ok { errorMessage = "Status \(statusCode): \(raw)" }
                }
            }
            
            if !ok && errorMessage == nil {
                errorMessage = "Status: \(statusCode)"
            }
            
            print("[APIService] [\(path)] success=\(ok) error=\(errorMessage ?? "nil")")
            DispatchQueue.main.async { completion(ok, errorMessage) }
        }.resume()
    }

    // Generic POST returning decodable
    private func postDecoding<T: Encodable, R: Decodable>(path: String, body: T, completion: @escaping (R?, Error?) -> Void) {
        var req = URLRequest(url: url(path))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONEncoder().encode(body)
        session.dataTask(with: req) { data, resp, err in
            let http = resp as? HTTPURLResponse
            let statusCode = http?.statusCode ?? -1
            print("[\(path)] status=\(statusCode)")
            
            if let err = err {
                DispatchQueue.main.async { completion(nil, err) }
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async { completion(nil, NSError(domain: "APIService", code: statusCode, userInfo: [NSLocalizedDescriptionKey: "No data received"])) }
                return
            }
            
            do {
                let decoded = try JSONDecoder().decode(R.self, from: data)
                DispatchQueue.main.async { completion(decoded, nil) }
            } catch {
                // If decoding fails, check if it's an error status JSON
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let status = json["status"] as? String, status == "error" {
                    let msg = json["message"] as? String ?? "Server Error"
                    print("[APIService] [\(path)] Server Error: \(msg)")
                    DispatchQueue.main.async { completion(nil, NSError(domain: "APIService", code: statusCode, userInfo: [NSLocalizedDescriptionKey: msg])) }
                } else {
                    print("[APIService] [\(path)] Decoding Error: \(error.localizedDescription)")
                    DispatchQueue.main.async { completion(nil, error) }
                }
            }
        }.resume()
    }

    // Generic GET returning decodable
    private func get<R: Decodable>(path: String, completion: @escaping (R?, Error?) -> Void) {
        let req = URLRequest(url: url(path))
        session.dataTask(with: req) { data, _, err in
            let decoded = data.flatMap { try? JSONDecoder().decode(R.self, from: $0) }
            DispatchQueue.main.async { completion(decoded, err) }
        }.resume()
    }

    // MARK: - Auth
    func registerPatient(_ patient: Patient, completion: @escaping (Bool, String?) -> Void) {
        post(path: "register.php", body: patient, completion: completion)
    }

    func loginPatient(_ req: LoginRequest, completion: @escaping (Patient?, String?) -> Void) {
        guard !req.email.isEmpty, !req.password.isEmpty else {
            completion(nil, "Email and Password cannot be empty.")
            return
        }
        
        postDecoding(path: "login.php", body: req) { (p: Patient?, err: Error?) in
            if let p = p {
                completion(p, nil)
            } else {
                if let err = err {
                    print("[APIService] loginPatient decode error: \(err)")
                }
                completion(nil, err?.localizedDescription ?? "Unknown error")
            }
        }
    }

    func getPatientProfile(email: String, completion: @escaping (Patient?) -> Void) {
        let enc = email.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? email
        get(path: "profile.php?email=\(enc)") { (p: Patient?, _) in completion(p) }
    }

    func getUserProfile(email: String, completion: @escaping (UserProfileResponse?) -> Void) {
        let enc = email.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? email
        get(path: "profile.php?email=\(enc)") { (p: UserProfileResponse?, _) in completion(p) }
    }

    func updateUserProfile(_ body: [String: String], completion: @escaping (Bool) -> Void) {
        post(path: "update_profile.php", body: body) { ok, _ in completion(ok) }
    }


    // MARK: - OTP
    func sendOtp(email: String, completion: @escaping (Bool, String?) -> Void) {
        post(path: "send_otp.php", body: ["email": email], completion: completion)
    }
    func verifyOtp(email: String, otp: String, completion: @escaping (Bool) -> Void) {
        post(path: "verify_otp.php", body: ["email": email, "otp": otp]) { ok, _ in completion(ok) }
    }
    func resetPassword(email: String, otp: String, newPassword: String, completion: @escaping (Bool) -> Void) {
        post(path: "reset_password.php", body: ["email": email, "otp": otp, "new_password": newPassword]) { ok, _ in completion(ok) }
    }

    // MARK: - Scores
    func getScoreHistory(email: String, domain: String, completion: @escaping ([ScoreResponse]) -> Void) {
        let enc = email.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? email
        let domEnc = domain.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? domain
        get(path: "get_scores.php?email=\(enc)&domain=\(domEnc)") { (r: [ScoreResponse]?, _) in completion(r ?? []) }
    }

    func saveMaasPre(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func savePanasPre(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func saveDassPre(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func saveCfqPre(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func savePhlmsPre(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    
    func savePreAssessmentScore(email: String, module: String, score: Float, completion: @escaping (Bool) -> Void) {
        let req = ModuleScoreRequest(email: email, module: module, score: score)
        post(path: "save_score.php", body: req) { ok, _ in completion(ok) }
    }

    func saveModuleScore(email: String, module: String, score: Float, completion: @escaping (Bool) -> Void) {
        let req = ModuleScoreRequest(email: email, module: module, score: score)
        post(path: "save_score.php", body: req) { ok, _ in completion(ok) }
    }

    func saveSrtPost(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func saveNbackPost(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func saveStroopPost(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func saveTaskSwitchPost(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }
    func saveSartPost(_ req: ScoreRequest, completion: @escaping (Bool) -> Void) { post(path: "save_score.php", body: req) { ok, _ in completion(ok) } }

    func predictMentalState(_ req: MLPredictRequest, completion: @escaping (MLPredictResponse?, Error?) -> Void) {
        postDecoding(path: "predict.php", body: req, completion: completion)
    }

    // MARK: - Audio
    func getAudios(module: String, completion: @escaping ([AudioResponse]) -> Void) {
        let enc = module.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? module
        get(path: "get_audios.php?module=\(enc)") { (r: [AudioResponse]?, _) in completion(r ?? []) }
    }

    // Helper added to match views
    func getSessions(module: String, completion: @escaping ([SessionInfo]) -> Void) {
        getAudios(module: module) { responses in
            let sessions = responses.map { SessionInfo(title: $0.title, description: $0.description ?? "", audioURL: $0.url ?? "") }
            completion(sessions)
        }
    }

    func getAssessmentStats(email: String, completion: @escaping (AssessmentStats) -> Void) {
        let enc = email.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? email
        get(path: "get_stats.php?email=\(enc)") { (stats: AssessmentStats?, _) in
            completion(stats ?? AssessmentStats(lastScore: 0, avgScore: 0, totalSessions: 0))
        }
    }

    func updatePatient(_ req: RegisterRequest, completion: @escaping (Bool, String?) -> Void) {
        post(path: "update_profile.php", body: req, completion: completion)
    }

    func deletePatient(email: String, completion: @escaping (Bool) -> Void) {
        post(path: "delete_user.php", body: ["email": email]) { ok, _ in completion(ok) }
    }

    // MARK: - Persistent Progress
    func saveModuleCompletion(record: ModuleCompletionRecord, completion: @escaping (Bool) -> Void) {
        post(path: "save_progress.php", body: record) { ok, _ in completion(ok) }
    }

    func getSavedProgress(email: String, completion: @escaping ([ModuleCompletionRecord]) -> Void) {
        let enc = email.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? email
        get(path: "get_progress.php?email=\(enc)") { (r: SavedProgressResponse?, _) in
            completion(r?.records ?? [])
        }
    }
}
