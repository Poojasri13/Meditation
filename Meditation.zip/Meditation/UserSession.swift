import Foundation
import SwiftUI

// Matches Android's SharedPreferences "UserPrefs"
class UserSession: ObservableObject {
    static let shared = UserSession()

    @Published var isLoggedIn: Bool = false
    @Published var userId: String = ""
    @Published var username: String = ""
    @Published var email: String = ""
    @Published var age: String = ""
    @Published var gender: String = ""
    @Published var profileImageBase64: String = ""

    private let defaults = UserDefaults.standard

    init() {
        load()
    }

    func checkAndResetDailyProgress() {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let today = formatter.string(from: Date())
        
        let lastResetDate = defaults.string(forKey: "last_daily_reset_date") ?? ""
        
        if lastResetDate != today && !email.isEmpty {
            print("[UserSession] New day detected (\(today)). Resetting progress flags and syncing.")
            resetProgress()
            defaults.set(today, forKey: "last_daily_reset_date")
            syncWithBackend()
        }
    }

    func load() {
        // We can keep isLoggedIn persistent if desired, but user said logout deletes progress.
        // Actually, let's keep the session if it exists.
        isLoggedIn = defaults.bool(forKey: "isLoggedIn")
        userId     = defaults.string(forKey: "user_id") ?? ""
        username   = defaults.string(forKey: "username") ?? ""
        email      = defaults.string(forKey: "email") ?? ""
        age        = defaults.string(forKey: "age") ?? ""
        gender     = defaults.string(forKey: "gender") ?? ""
        profileImageBase64 = defaults.string(forKey: "profile_image") ?? ""
        
        if isLoggedIn && !email.isEmpty {
            syncWithBackend()
        }
    }

    func save(userId: String, email: String, age: String = "", gender: String = "", profileImageBase64: String = "") {
        self.userId   = userId
        self.username = userId 
        self.email    = email
        self.age      = age
        self.gender   = gender
        if !profileImageBase64.isEmpty {
            self.profileImageBase64 = profileImageBase64
        }
        self.isLoggedIn = true
        defaults.set(true,   forKey: "isLoggedIn")
        defaults.set(userId, forKey: "user_id")
        defaults.set(userId, forKey: "username")
        defaults.set(email,  forKey: "email")
        defaults.set(age,    forKey: "age")
        defaults.set(gender, forKey: "gender")
        if !profileImageBase64.isEmpty {
            defaults.set(profileImageBase64, forKey: "profile_image")
        }
        
        // Guarantee a fresh 0% daily task start every single time a user logs in
        resetProgress()
        
        syncWithBackend()
    }

    func signOut() {
        isLoggedIn = false
        userId = ""; username = ""; email = ""; age = ""; gender = ""; profileImageBase64 = ""
        let d = defaults
        ["isLoggedIn","user_id","username","email","age","gender","profile_image","permanently_saved_progress"].forEach { d.removeObject(forKey: $0) }
        resetProgress()
    }

    func resetProgress() {
        print("[UserSession] Resetting session progress flags.")
        let modules = ["focused_attention", "working_memory", "present_moment", "cognitive_flexibility", "emotional_regulation"]
        
        for m in modules {
            defaults.removeObject(forKey: "\(m)_pre_done")
            defaults.removeObject(forKey: "\(m)_assessment_done")
            defaults.removeObject(forKey: "\(m)_task_done")
            defaults.removeObject(forKey: "\(m)_current_answers")
            defaults.removeObject(forKey: "\(m)_last_task_score")
            defaults.removeObject(forKey: "\(m)_last_assessment_score")
        }
    }

    func syncWithBackend() {
        guard !email.isEmpty else { return }
        print("[UserSession] Syncing with backend for \(email)...")
        
        // Fetch and restore the profile image from the server
        APIService.shared.getPatientProfile(email: email) { patient in
            DispatchQueue.main.async {
                if let img = patient?.profile_image, !img.isEmpty {
                    self.profileImageBase64 = img
                    self.defaults.set(img, forKey: "profile_image")
                    print("[UserSession] Profile image restored from server.")
                }
            }
        }
        
        APIService.shared.getSavedProgress(email: email) { records in
            DispatchQueue.main.async {
                // Store all historical records locally for "Saved Progress" view
                if let data = try? JSONEncoder().encode(records) {
                    self.defaults.set(data, forKey: "permanently_saved_progress")
                }
                
                print("[UserSession] Sync complete. Saved \(records.count) records to local archives.")
                // Notify UI to refresh
                self.objectWillChange.send()
            }
        }
    }
}

// MARK: - AssessmentStatus helper
func isPreDone(moduleType: String) -> Bool {
    UserDefaults.standard.bool(forKey: "\(moduleType)_pre_done")
}
func setPreDone(moduleType: String) {
    UserDefaults.standard.set(true, forKey: "\(moduleType)_pre_done")
}

// New specific helpers
func isAssessmentDone(moduleType: String) -> Bool {
    UserDefaults.standard.bool(forKey: "\(moduleType)_assessment_done")
}
func setAssessmentDone(moduleType: String) {
    UserDefaults.standard.set(true, forKey: "\(moduleType)_assessment_done")
    setPreDone(moduleType: moduleType) 
}

func isTaskDone(moduleType: String) -> Bool {
    UserDefaults.standard.bool(forKey: "\(moduleType)_task_done")
}
func setTaskDone(moduleType: String) {
    UserDefaults.standard.set(true, forKey: "\(moduleType)_task_done")
    setPreDone(moduleType: moduleType) 
}

// Answer Persistence
func saveAnswers(moduleType: String, answers: [Int: Int]) {
    let stringKeyDict = Dictionary(uniqueKeysWithValues: answers.map { ("\($0.key)", $0.value) })
    if let data = try? JSONEncoder().encode(stringKeyDict) {
        UserDefaults.standard.set(data, forKey: "\(moduleType)_current_answers")
    }
}

func loadAnswers(moduleType: String) -> [Int: Int] {
    guard let data = UserDefaults.standard.data(forKey: "\(moduleType)_current_answers") else { return [:] }
    if let stringKeyDict = try? JSONDecoder().decode([String: Int].self, from: data) {
        return Dictionary(uniqueKeysWithValues: stringKeyDict.compactMap { (Int($0.key), $0.value) as? (Int, Int) })
    }
    return [:]
}

// MARK: - Persistent Save Trigger
func checkAndSaveCompletion(moduleType: String, email: String) {
    print("[UserSession] Checking completion for \(moduleType) (email: \(email))")
    
    let modules = ["focused_attention", "working_memory", "present_moment", "cognitive_flexibility", "emotional_regulation"]
    
    // Ensure we have latest flags
    let assessmentsDone = modules.filter { isAssessmentDone(moduleType: $0) }.count
    let tasksDone = modules.filter { isTaskDone(moduleType: $0) }.count

    let assessmentDone = isAssessmentDone(moduleType: moduleType)
    let taskDone = isTaskDone(moduleType: moduleType)
    
    let totalItems = modules.count * 2
    let dailyProgress = Float(assessmentsDone + tasksDone) / Float(totalItems) * 100.0
    
    if assessmentDone && taskDone {
        let answers = loadAnswers(moduleType: moduleType)
        let totalScore = answers.values.reduce(0, +)
        let assessmentPercent = Float(totalScore) / 30.0 * 100.0
        let taskScore = UserDefaults.standard.float(forKey: "\(moduleType)_last_task_score")
        let unifiedScore = (assessmentPercent + taskScore) / 2.0
        
        print("[UserSession] Module \(moduleType) complete. Saving to backend. Score: \(unifiedScore)%")
        
        APIService.shared.saveModuleScore(email: email, module: moduleType, score: unifiedScore) { success in
            print("[UserSession] Module score save status: \(success)")
        }
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let dateStr = formatter.string(from: Date())
        
        let record = ModuleCompletionRecord(
            email: email,
            moduleType: moduleType,
            percentageScore: assessmentPercent,
            taskScore: taskScore,
            dailyProgress: dailyProgress,
            completionDate: dateStr,
            graphData: [assessmentPercent, taskScore]
        )
        
        APIService.shared.saveModuleCompletion(record: record) { success in
            print("[UserSession] daily_progress DB save for \(moduleType): \(success)")
            if success {
                // Refresh local records after save
                UserSession.shared.syncWithBackend()
            }
        }

        // Schedule (or reschedule) the 24-hour mindful reminder
        NotificationManager.shared.scheduleReminder()
    }
}

func getLocalSavedProgress() -> [ModuleCompletionRecord] {
    guard let data = UserDefaults.standard.data(forKey: "permanently_saved_progress") else { return [] }
    return (try? JSONDecoder().decode([ModuleCompletionRecord].self, from: data)) ?? []
}

func saveLocalProgress(_ records: [ModuleCompletionRecord]) {
    if let data = try? JSONEncoder().encode(records) {
        UserDefaults.standard.set(data, forKey: "permanently_saved_progress")
    }
}
