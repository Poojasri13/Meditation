import SwiftUI

struct StroopTaskView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var currentColor = ""
    @State private var currentWord = ""
    @State private var currentInkColor: Color = .black
    @State private var score = 0
    @State private var trialCount = 0
    @State private var gameStarted = false
    @State private var gameEnded = false
    @State private var isLoading = false
    @State private var responseGiven = false

    private let totalTrials = 20
    private let colors: [String: Color] = [
        "RED": .red,
        "BLUE": .blue,
        "GREEN": .green,
        "YELLOW": .yellow
    ]

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color(.systemBackground).ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer().frame(height: 40)
                if !gameStarted && !gameEnded {
                    VStack(spacing: 20) {
                        Image(systemName: "circle.grid.cross.fill")
                            .font(.system(size: 80))
                            .foregroundColor(moduleColor("cognitive_flexibility"))
                            .padding(.bottom, 20)
                        
                        Text("Stroop Challenge")
                            .font(.title2.bold())
                        
                        Text("Pick the button that matches the INK COLOR, not what the word says.")
                            .font(.subheadline).foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                        
                        Button(action: startGame) {
                            Text("Start Task").font(.headline)
                        }
                        .buttonStyle(PrimaryButtonStyle(bgColor: moduleColor("cognitive_flexibility")))
                    }
                    .padding(.horizontal, 40)
                } else if gameStarted && !gameEnded {
                    VStack(spacing: 40) {
                        Text("Trial \(trialCount + 1) of \(totalTrials)")
                            .font(.caption).foregroundColor(.gray)
                        
                        Text(currentWord)
                            .font(.system(size: 80, weight: .bold))
                            .foregroundColor(currentInkColor)
                            .transition(.scale)
                            .id(trialCount)
                        
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                            ForEach(colors.sorted(by: { $0.key < $1.key }), id: \.key) { name, color in
                                Button(action: { handlePress(name) }) {
                                    Text(name)
                                        .font(.headline)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(color.opacity(0.1))
                                        .foregroundColor(color)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12)
                                                .stroke(color, lineWidth: 2)
                                        )
                                }
                                .cornerRadius(12)
                            }
                        }
                        .padding(.horizontal, 40)
                    }
                } else {
                    VStack(spacing: 30) {
                        Image(systemName: "star.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.yellow)
                            .padding(.bottom, 20)
                        
                        Text("Task Complete!")
                            .font(.title2.bold())
                        
                        Text("Final Score: \(Int(calculateScore()))%")
                            .font(.title3)
                        
                        if isLoading {
                            ProgressView().padding()
                        } else {
                            Button(action: { route = .home }) {
                                Text("Return to Home").font(.headline)
                            }
                            .buttonStyle(PrimaryButtonStyle())
                        }
                    }
                    .padding(.horizontal, 40)
                }
            }
            
            GlobalBackButton(color: moduleColor("cognitive_flexibility")) {
                route = .moduleHome(type: "cognitive_flexibility")
            }
            .padding(.leading, 12)
            .padding(.top, 8)
        }
    }

    private func startGame() {
        gameStarted = true
        gameEnded = false
        score = 0
        trialCount = 0
        showNextTrial()
    }

    private func showNextTrial() {
        let keys = Array(colors.keys)
        currentWord = keys.randomElement()!
        
        // Randomly decide if word matches ink color
        if Bool.random() {
            currentInkColor = colors[currentWord]!
        } else {
            currentInkColor = colors[keys.randomElement()!]!
        }
        
        responseGiven = false
    }

    private func handlePress(_ chosenName: String) {
        guard !responseGiven else { return }
        responseGiven = true
        
        // Correct if chosen name's color matches current ink color
        if colors[chosenName] == currentInkColor {
            score += 1
        }
        
        trialCount += 1
        if trialCount < totalTrials {
            showNextTrial()
        } else {
            finishGame()
        }
    }

    private func finishGame() {
        gameStarted = false
        gameEnded = true
        saveScore()
    }

    private func calculateScore() -> Float {
        guard totalTrials > 0 else { return 100 }
        return Float(score) / Float(totalTrials) * 100
    }

    private func saveScore() {
        isLoading = true
        let s = calculateScore()
        UserDefaults.standard.set(s, forKey: "cognitive_flexibility_last_task_score")
        
        isLoading = false
        setTaskDone(moduleType: "cognitive_flexibility")
        checkAndSaveCompletion(moduleType: "cognitive_flexibility", email: session.email)
    }
}
