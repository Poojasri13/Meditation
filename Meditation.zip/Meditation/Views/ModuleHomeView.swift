import SwiftUI

struct ModuleHomeView: View {
    let moduleType: String
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var sessions: [SessionInfo] = []
    @State private var isLoading = false
    @State private var stats: AssessmentStats?
    
    // Questionnaire State
    @State private var answers: [Int: Int] = [:] // Question index : Rating (1-6)
    @State private var isSaving = false
    @State private var showSavedToast = false

    private var questions: [String] {
        switch moduleType {
        case "focused_attention":
            return [
                "I find it hard to stay focused on one task for a long time.",
                "My mind wanders while doing important work.",
                "I get distracted easily by small noises or thoughts.",
                "I struggle to bring my attention back when it drifts.",
                "I lose concentration even during simple activities."
            ]
        case "working_memory":
            return [
                "I forget instructions quickly after hearing them.",
                "I struggle to remember things while doing another task.",
                "I lose track of what I was thinking about.",
                "I forget tasks I planned to do during the day.",
                "I find it hard to hold information in my mind briefly."
            ]
        case "present_moment":
            return [
                "I think more about the past than the present.",
                "I worry about the future frequently.",
                "I find it hard to enjoy the present moment.",
                "My thoughts pull away from what I am doing now.",
                "I do activities without being fully aware of them."
            ]
        case "cognitive_flexibility":
            return [
                "I struggle to adapt when plans suddenly change.",
                "I find it hard to see situations from different perspectives.",
                "I get stuck on one way of thinking.",
                "I feel uncomfortable when things are uncertain.",
                "I find it difficult to shift my attention between tasks."
            ]
        case "emotional_regulation":
            return [
                "I react strongly to small problems.",
                "I find it hard to calm down when upset.",
                "My emotions control my behavior sometimes.",
                "I struggle to manage stress effectively.",
                "I feel overwhelmed by emotions frequently."
            ]
        default: return []
        }
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
                Color(.systemBackground).ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 32) {
                        // Spacing for floating back button
                        Spacer().frame(height: 50)
                        
                        // Header
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(moduleTitle(moduleType))
                                    .font(.title).bold()
                                Text("Your cognitive journey")
                                    .font(.subheadline).foregroundColor(.gray)
                            }
                            Spacer()
                            Image(systemName: moduleIcon(moduleType))
                                .font(.title)
                                .foregroundColor(moduleColor(moduleType))
                        }
                        .padding(.horizontal)

                        // 1️⃣ SECTION: ENHANCED ATTENTION
                        VStack(alignment: .leading, spacing: 20) {
                            Text("1️⃣ Enhanced Attention")
                                .font(.headline)
                                .padding(.horizontal)

                            // Cognitive Task Card
                            Button(action: {
                                navigateToTask()
                            }) {
                                HStack(spacing: 16) {
                                    Image(systemName: "brain.head.profile")
                                        .font(.title2)
                                        .foregroundColor(.white)
                                        .frame(width: 44, height: 44)
                                        .background(moduleColor(moduleType))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Cognitive Challenge")
                                            .font(.body.bold())
                                        Text("Enhance your \(moduleTitle(moduleType))")
                                            .font(.caption).foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Image(systemName: "play.fill")
                                        .font(.footnote)
                                        .foregroundColor(moduleColor(moduleType))
                                }
                                .padding()
                                .background(moduleColor(moduleType).opacity(0.1))
                                .cornerRadius(16)
                            }
                            .padding(.horizontal)
                            .buttonStyle(PlainButtonStyle())

                            // Audio Sessions List
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Training Sessions")
                                    .font(.subheadline).bold()
                                    .foregroundColor(.gray)
                                    .padding(.horizontal)
                                
                                if isLoading {
                                    ProgressView().padding()
                                } else if sessions.isEmpty {
                                    Text("No sessions found.")
                                        .font(.caption).foregroundColor(.gray)
                                        .padding(.horizontal)
                                } else {
                                    ForEach(Array(sessions.enumerated()), id: \.offset) { index, sessionInfo in
                                        SessionRow(session: sessionInfo, index: index) {
                                            route = .session(audioURL: sessionInfo.audioURL,
                                                             audioTitle: sessionInfo.title,
                                                             audioDesc: sessionInfo.description,
                                                             index: index)
                                        }
                                    }
                                }
                            }
                        }

                        Divider().padding(.horizontal)

                        // 2️⃣ SECTION: TRAINING SYSTEMS (Pre-Assessment)
                        VStack(alignment: .leading, spacing: 20) {
                            HStack {
                                Text("2️⃣ Training Systems")
                                    .font(.headline)
                                Spacer()
                                if isPreDone(moduleType: moduleType) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.green)
                                }
                            }
                            .padding(.horizontal)

                            VStack(spacing: 24) {
                                ForEach(0..<questions.count, id: \.self) { index in
                                    VStack(alignment: .leading, spacing: 12) {
                                        Text("\(index + 1). \(questions[index])")
                                            .font(.subheadline).bold()
                                            .foregroundColor(.primary)
                                        
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack(spacing: 12) {
                                                ForEach(1...6, id: \.self) { rating in
                                                    Button(action: { 
                                                        answers[index] = rating 
                                                        saveAnswers(moduleType: moduleType, answers: answers)
                                                    }) {
                                                        VStack(spacing: 4) {
                                                            Text("\(rating)")
                                                                .font(.caption).bold()
                                                                .frame(width: 32, height: 32)
                                                                .background(answers[index] == rating ? moduleColor(moduleType) : Color(.systemGray6))
                                                                .foregroundColor(answers[index] == rating ? .white : .primary)
                                                                .clipShape(Circle())
                                                            
                                                            if rating == 1 || rating == 6 {
                                                                Text(rating == 1 ? "Always" : "Never")
                                                                    .font(.system(size: 8))
                                                                    .foregroundColor(.gray)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            .padding(.vertical, 4)
                                        }
                                    }
                                    .padding()
                                    .background(Color(.secondarySystemBackground).opacity(0.4))
                                    .cornerRadius(12)
                                }
                                
                                Button(action: savePreAssessment) {
                                    if isSaving {
                                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    } else {
                                        Text(isPreDone(moduleType: moduleType) ? "Update Pre-Assessment" : "Submit Pre-Assessment")
                                            .font(.headline)
                                    }
                                }
                                .buttonStyle(PrimaryButtonStyle(bgColor: answers.count == 5 ? moduleColor(moduleType) : Color.gray.opacity(0.5)))
                                .disabled(isSaving || answers.count < 5)
                                .padding(.top, 10)
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.bottom, 40)
                }

                GlobalBackButton(color: moduleColor(moduleType)) {
                    route = .home
                }
                .padding(.leading, 12)
                .padding(.top, 8)
                
                if showSavedToast {
                    VStack {
                        Spacer()
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.white)
                            Text("Updated")
                                .font(.subheadline.bold())
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .background(Color.green)
                        .cornerRadius(25)
                        .shadow(radius: 10)
                        .padding(.bottom, 50)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                    .frame(maxWidth: .infinity)
                    .ignoresSafeArea()
                }
            }
        .onAppear(perform: loadModuleData)
    }

    private func savePreAssessment() {
        isSaving = true
        let totalScore = answers.values.reduce(0, +)
        let percentage = (Float(totalScore) / 30.0) * 100.0
        
        isSaving = false
        setAssessmentDone(moduleType: moduleType)
        checkAndSaveCompletion(moduleType: moduleType, email: session.email)
        
        withAnimation {
            showSavedToast = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            withAnimation {
                showSavedToast = false
            }
        }
    }

    private func loadModuleData() {
        // answers state is fresh by default ([:]) and we no longer load previous answers
        // self.answers = loadAnswers(moduleType: moduleType)
        isLoading = true
        APIService.shared.getAssessmentStats(email: session.email) { s in
            self.stats = s
        }
        
        APIService.shared.getSessions(module: moduleType) { ss in
            self.isLoading = false
            self.sessions = ss
        }
    }

    private func navigateToTask() {
        switch moduleType {
        case "focused_attention":    route = .nBack
        case "working_memory":       route = .sart
        case "present_moment":       route = .srt(moduleType: moduleType)
        case "cognitive_flexibility": route = .stroop
        case "emotional_regulation":  route = .taskSwitch
        default: break
        }
    }
}

struct StatBadge: View {
    let title: String
    let val: String
    let color: Color
    var body: some View {
        VStack(spacing: 8) {
            Text(val).font(.title2.bold()).foregroundColor(color)
            Text(title).font(.caption).foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(color.opacity(0.08))
        .cornerRadius(12)
    }
}

struct SessionRow: View {
    let session: SessionInfo
    let index: Int
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                ZStack {
                    Circle().fill(Color(.systemGray6))
                    Text("\(index + 1)").font(.footnote).bold().foregroundColor(.gray)
                }
                .frame(width: 40, height: 40)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(session.title).font(.body.bold()).foregroundColor(.primary)
                    Text(session.description).lineLimit(1).font(.caption).foregroundColor(.gray)
                }
                
                Spacer()
                
                Image(systemName: "play.circle.fill")
                    .font(.title2)
                    .foregroundColor(Color(hex: "#7C4DFF"))
            }
            .padding(.horizontal)
            .padding(.vertical, 12)
            .background(Color(.secondarySystemBackground).opacity(0.3))
            .cornerRadius(16)
            .padding(.horizontal)
        }
        .buttonStyle(PlainButtonStyle())
    }
}
