import SwiftUI

struct ResetAccountView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var showConfirmReset = false
    @State private var showConfirmDelete = false

    var body: some View {
        NavigationView {
                VStack(spacing: 32) {
                    // Visual icon
                    VStack(spacing: 12) {
                        Image(systemName: "trash.circle.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.red)
                            .padding(.top, 40)
                        
                        Text("Reset or Delete Account")
                            .font(.title2).bold()
                        
                        Text("These actions are irreversible.")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.gray)
                    }

                    VStack(spacing: 20) {
                        // Reset progress
                        Button(action: { showConfirmReset = true }) {
                            HStack {
                                Image(systemName: "arrow.counterclockwise")
                                Text("Reset Session Progress")
                                Spacer()
                            }
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(12)
                        }
                        .alert(isPresented: $showConfirmReset) {
                            Alert(
                                title: Text("Reset Progress?"),
                                message: Text("All your session progress will be cleared. Do you wish to proceed?"),
                                primaryButton: .destructive(Text("Reset")) {
                                    session.resetProgress()
                                },
                                secondaryButton: .cancel()
                            )
                        }

                        // Delete account
                        Button(action: { showConfirmDelete = true }) {
                            HStack {
                                Image(systemName: "person.badge.minus")
                                Text("Delete My Account")
                                Spacer()
                            }
                            .foregroundColor(.red)
                            .padding()
                            .background(Color.red.opacity(0.1))
                            .cornerRadius(12)
                        }
                        .alert(isPresented: $showConfirmDelete) {
                            Alert(
                                title: Text("Delete Account?"),
                                message: Text("This will permanently delete your account and all associated data. This action CANNOT be undone."),
                                primaryButton: .destructive(Text("Delete Permanently")) {
                                    APIService.shared.deletePatient(email: session.email) { ok in
                                        if ok {
                                            session.signOut()
                                            route = .login
                                        }
                                    }
                                },
                                secondaryButton: .cancel()
                            )
                        }
                    }
                    .padding(.horizontal)

                    Spacer()
                }
                .navigationTitle("Danger Zone")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Back") { route = .profile }
                    }
                }
            }
    }
}
