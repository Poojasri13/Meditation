import SwiftUI

struct ModuleIntroView: View {
    let moduleType: String
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    var body: some View {
        ZStack {
            moduleColor(moduleType).opacity(0.1).ignoresSafeArea()
            
            VStack(spacing: 30) {
                    Spacer()
                    
                    // Icon
                    ZStack {
                        Circle()
                            .fill(moduleColor(moduleType).opacity(0.2))
                        Image(systemName: moduleIcon(moduleType))
                            .font(.system(size: 60))
                            .foregroundColor(moduleColor(moduleType))
                    }
                    .frame(width: 120, height: 120)
                    .shadow(color: moduleColor(moduleType).opacity(0.3), radius: 10, x: 0, y: 5)

                    // Title
                    VStack(spacing: 12) {
                        Text(moduleTitle(moduleType))
                            .font(.system(size: 32, weight: .bold))
                        
                        Text("Welcome to \(moduleTitle(moduleType)). We'll guide you through techniques to improve your mind and cognitive performance.")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }

                    // Begin Button
                    Button(action: {
                        route = .moduleHome(type: moduleType)
                    }) {
                        Text("Begin Module")
                            .font(.headline)
                    }
                    .buttonStyle(PrimaryButtonStyle(bgColor: moduleColor(moduleType)))
                    .padding(.horizontal, 40)

                    Spacer()
                }
            
            // Close Button
            VStack {
                HStack {
                    Button(action: { route = .home }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title)
                            .foregroundColor(.gray.opacity(0.5))
                    }
                    .padding()
                    Spacer()
                }
                Spacer()
            }
        }
    }
}
