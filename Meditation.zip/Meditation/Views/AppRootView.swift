import SwiftUI

enum AppRoute: Equatable {
    case splash
    case login
    case signup
    case forgotPassword
    case intro          // shown after signup
    case home
    case profile
    case updateInfo
    case resetAccount
    case privacy
    case moduleIntro(type: String)
    case moduleHome(type: String)
    case session(audioURL: String, audioTitle: String, audioDesc: String, index: Int)
    case progressDashboard(scoreType: String)
    // Cognitive tasks
    case nBack
    case sart
    case srt(moduleType: String)
    case stroop
    case taskSwitch
    case timetable
    case savedProgress
}

struct AppRootView: View {
    @StateObject var session = UserSession.shared
    @State var route: AppRoute = .splash

    var body: some View {
        ZStack {
            switch route {
            case .splash:
                SplashView(appRoute: $route)
            case .login:
                LoginView(route: $route)
            case .signup:
                SignupView(route: $route)
            case .forgotPassword:
                ForgotPasswordView(route: $route)
            case .intro:
                IntroView(route: $route)
            case .home:
                HomeView(route: $route)
            case .profile:
                ProfileView(route: $route)
            case .updateInfo:
                UpdateInfoView(route: $route)
            case .resetAccount:
                ResetAccountView(route: $route)
            case .privacy:
                PrivacyView(route: $route)
            case .moduleIntro(let type):
                ModuleIntroView(moduleType: type, route: $route)
            case .moduleHome(let type):
                ModuleHomeView(moduleType: type, route: $route)
            case .session(let url, let title, let desc, let idx):
                SessionView(audioURL: url, audioTitle: title, audioDesc: desc, sessionIndex: idx, route: $route)
            case .progressDashboard(let st):
                ProgressDashboardView(scoreType: st, route: $route)
            case .nBack:
                NBackView(route: $route)
            case .sart:
                SARTView(route: $route)
            case .srt(let mt):
                SRTView(moduleType: mt, route: $route)
            case .stroop:
                StroopTaskView(route: $route)
            case .taskSwitch:
                TaskSwitchView(route: $route)
            case .timetable:
                TimetableListView(route: $route)
            case .savedProgress:
                SavedProgressView(route: $route)
            }
        }
        .environmentObject(session)
    }
}
