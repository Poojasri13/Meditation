import SwiftUI
import AVFoundation
import CoreMedia

struct SessionView: View {
    let audioURL: String
    let audioTitle: String
    let audioDesc: String
    let sessionIndex: Int
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var player: AVPlayer?
    @State private var isPlaying = false
    @State private var currentTime: Double = 0
    @State private var duration: Double = 1
    @State private var isLoading = true
    @State private var progress: Float = 0.0

    var body: some View {
        ZStack {
                // Background Gradient
                LinearGradient(colors: [Color(hex: "#7C4DFF").opacity(0.1), Color(.systemBackground)],
                            startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack(spacing: 32) {
                    // Header
                    HStack {
                        Button(action: { close() }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.title2)
                                .foregroundColor(.gray.opacity(0.5))
                        }
                        Spacer()
                    }
                    .padding()

                    // Cover Art
                    ZStack {
                        Circle()
                            .fill(Color(hex: "#7C4DFF").opacity(0.15))
                            .frame(width: 200, height: 200)
                        
                        Image(systemName: "leaf.fill")
                            .font(.system(size: 80))
                            .foregroundColor(Color(hex: "#7C4DFF"))
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.3), radius: 10, x: 0, y: 5)
                    }
                    .padding(.top, 20)

                    // Title & Desc
                    VStack(spacing: 12) {
                        Text(audioTitle)
                            .font(.title).bold()
                            .multilineTextAlignment(.center)
                        
                        Text(audioDesc)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }

                    // Seeker
                    VStack(spacing: 8) {
                        Slider(value: Binding(get: { currentTime }, set: { seek(to: $0) }), in: 0...duration)
                            .accentColor(Color(hex: "#7C4DFF"))
                        
                        HStack {
                            Text(formatTime(currentTime)).font(.caption).foregroundColor(.gray)
                            Spacer()
                            Text(formatTime(duration)).font(.caption).foregroundColor(.gray)
                        }
                    }
                    .padding(.horizontal, 30)

                    // Controls
                    HStack(spacing: 40) {
                        Button(action: { skip(-10) }) {
                            Image(systemName: "gobackward.10").font(.title)
                        }
                        
                        Button(action: { togglePlay() }) {
                            Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                                .font(.system(size: 80))
                                .foregroundColor(Color(hex: "#7C4DFF"))
                        }
                        
                        Button(action: { skip(10) }) {
                            Image(systemName: "goforward.10").font(.title)
                        }
                    }
                    .foregroundColor(Color(hex: "#7C4DFF"))

                    Spacer()

                    if progress >= 0.95 {
                        Button(action: completeSession) {
                            Text("Complete Session")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color(hex: "#7C4DFF"))
                                .foregroundColor(.white)
                                .cornerRadius(16)
                        }
                        .padding(.horizontal, 30)
                        .padding(.bottom, 30)
                    }
                }
            }
        .onAppear(perform: setupPlayer)
        .onDisappear { player?.pause(); player = nil }
    }

    private func setupPlayer() {
        guard let url = URL(string: audioURL) else { return }
        let playerItem = AVPlayerItem(url: url)
        self.player = AVPlayer(playerItem: playerItem)
        
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { time in
            self.currentTime = time.seconds
            self.duration = playerItem.duration.seconds
            if duration > 0 {
                self.progress = Float(currentTime / duration)
            }
        }
        
        isLoading = false
    }

    private func togglePlay() {
        if isPlaying {
            player?.pause()
        } else {
            player?.play()
        }
        isPlaying.toggle()
    }

    private func seek(to time: Double) {
        player?.seek(to: CMTime(seconds: time, preferredTimescale: 600))
    }

    private func skip(_ seconds: Double) {
        let newTime = currentTime + seconds
        seek(to: max(0, min(newTime, duration)))
    }

    private func formatTime(_ time: Double) -> String {
        let mins = Int(time) / 60
        let secs = Int(time) % 60
        return String(format: "%02d:%02d", mins, secs)
    }

    private func completeSession() {
        // Here we can call API to mark session done
        close()
    }

    private func close() {
        player?.pause()
        route = .home // Or back to module home
    }
}
