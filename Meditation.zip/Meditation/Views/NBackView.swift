import SwiftUI

struct NBackView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var sequence: [Int] = []
    @State private var currentIndex = 0
    @State private var score = 0
    @State private var totalTargets = 0
    @State private var gameStarted = false
    @State private var gameEnded = false
    @State private var currentStimulus: Int?
    @State private var timer: Timer?
    @State private var responseGiven = false
    @State private var isLoading = false

    private let n = 2
    private let totalTrials = 15
    private let stimulusInterval: TimeInterval = 2.0 // seconds

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color(.systemBackground).ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer().frame(height: 40)
                if !gameStarted && !gameEnded {
                    VStack(spacing: 20) {
                        Image(systemName: "brain.head.profile")
                            .font(.system(size: 80))
                            .foregroundColor(moduleColor("focused_attention"))
                            .padding(.bottom, 20)
                        
                        Text("N-Back Challenge (N=2)")
                            .font(.title2.bold())
                        
                        Text("Press the button if the current number matches the one shown 2 steps back.")
                            .font(.subheadline).foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                        
                        Button(action: startGame) {
                            Text("Start Task").font(.headline)
                        }
                        .buttonStyle(PrimaryButtonStyle(bgColor: moduleColor("focused_attention")))
                    }
                    .padding(.horizontal, 40)
                } else if gameStarted && !gameEnded {
                    VStack(spacing: 40) {
                        Text("Trial \(currentIndex + 1) of \(totalTrials)")
                            .font(.caption).foregroundColor(.gray)
                        
                        if let stimulus = currentStimulus {
                            Text("\(stimulus)")
                                .font(.system(size: 100, weight: .bold))
                                .foregroundColor(.primary)
                                .transition(.scale)
                                .id(currentIndex)
                        }
                        
                        HStack(spacing: 20) {
                            Button(action: handleMatchPress) {
                                Text("MATCH")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color(hex: "#7C4DFF"))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }
                            .disabled(responseGiven)
                            
                            Button(action: { responseGiven = true }) {
                                Text("NO MATCH")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.gray.opacity(0.1))
                                    .foregroundColor(.primary)
                                    .cornerRadius(12)
                            }
                            .disabled(responseGiven)
                        }
                        .padding(.horizontal, 30)
                    }
                } else {
                    VStack(spacing: 30) {
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.green)
                            .padding(.bottom, 20)
                        
                        Text("Task Complete!")
                            .font(.title2.bold())
                        
                        Text("Your score: \(Int(calculateScore()))%")
                            .font(.title3)
                            .foregroundColor(moduleColor("focused_attention"))
                        
                        if isLoading {
                            ProgressView().padding()
                        } else {
                            Button(action: { route = .home }) {
                                Text("Return to Home").font(.headline)
                            }
                            .buttonStyle(PrimaryButtonStyle())
                        }
                    }
                    .padding(.horizontal, 40)
                }
            }
            
            GlobalBackButton(color: moduleColor("focused_attention")) {
                route = .moduleHome(type: "focused_attention")
            }
            .padding(.leading, 12)
            .padding(.top, 8)
        }
    }

    private func startGame() {
        sequence = (0..<totalTrials).map { _ in Int.random(in: 1...9) }
        // Ensure some matches
        for i in 2..<totalTrials {
            if Int.random(in: 0...3) == 0 {
                sequence[i] = sequence[i-2]
            }
        }
        
        currentIndex = 0
        score = 0
        totalTargets = (n..<totalTrials).filter { sequence[$0] == sequence[$0-n] }.count
        gameStarted = true
        gameEnded = false
        responseGiven = false
        
        showNextStimulus()
    }

    private func showNextStimulus() {
        if currentIndex < totalTrials {
            currentStimulus = sequence[currentIndex]
            responseGiven = false
            
            DispatchQueue.main.asyncAfter(deadline: .now() + stimulusInterval) {
                if currentIndex < totalTrials - 1 {
                    currentIndex += 1
                    showNextStimulus()
                } else {
                    finishGame()
                }
            }
        }
    }

    private func handleMatchPress() {
        guard !responseGiven else { return }
        responseGiven = true
        
        if currentIndex >= n && sequence[currentIndex] == sequence[currentIndex-n] {
            score += 1
        } else {
            // Mistake
            if score > 0 { score -= 1 }
        }
    }

    private func finishGame() {
        gameStarted = false
        gameEnded = true
        saveScore()
    }

    private func calculateScore() -> Float {
        guard totalTargets > 0 else { return 100 }
        return min(100, max(0, Float(score) / Float(totalTargets) * 100))
    }

    private func saveScore() {
        isLoading = true
        let s = calculateScore()
        UserDefaults.standard.set(s, forKey: "focused_attention_last_task_score")
        
        isLoading = false
        setTaskDone(moduleType: "focused_attention")
        checkAndSaveCompletion(moduleType: "focused_attention", email: session.email)
    }
}
