import SwiftUI

struct SRTView: View {
    let moduleType: String
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var gameStarted = false
    @State private var gameEnded = false
    @State private var showStimulus = false
    @State private var startTime: Date?
    @State private var reactionTimes: [Double] = []
    @State private var trialCount = 0
    @State private var isLoading = false
    
    // Randomization State
    @State private var targetOffset: CGSize = .zero
    @State private var targetScale: CGFloat = 1.0
    
    private let totalTrials = 10
    private let waitRange = 2.0...5.0

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color(.systemBackground).ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer().frame(height: 40)
                if !gameStarted && !gameEnded {
                    VStack(spacing: 20) {
                        Image(systemName: "timer")
                            .font(.system(size: 80))
                            .foregroundColor(moduleColor("present_moment"))
                            .padding(.bottom, 20)
                        
                        Text("SRT Challenge")
                            .font(.title2.bold())
                        
                        Text("Watch closely! Press the circle as soon as it appears.")
                            .font(.subheadline).foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                        
                        Button(action: startGame) {
                            Text("Start Task").font(.headline)
                        }
                        .buttonStyle(PrimaryButtonStyle(bgColor: moduleColor("present_moment")))
                    }
                    .padding(.horizontal, 40)
                } else if gameStarted && !gameEnded {
                    GeometryReader { geo in
                        VStack {
                            ZStack {
                                if showStimulus {
                                    Circle()
                                        .fill(Color.green)
                                        .frame(width: 150, height: 150)
                                        .scaleEffect(targetScale)
                                        .offset(targetOffset)
                                        .onTapGesture {
                                            handlePress()
                                        }
                                        .shadow(color: .green.opacity(0.4), radius: 20)
                                } else {
                                    Text("Wait for it...")
                                        .font(.headline).foregroundColor(.gray)
                                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                                }
                            }
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            
                            Text("Trial \(trialCount + 1) of \(totalTrials)")
                                .font(.caption).foregroundColor(.gray)
                                .padding(.bottom, 40)
                        }
                        .onAppear {
                            // Initial random pos if needed, but scheduleNextTrial handles it
                        }
                        .onChange(of: showStimulus) { newValue in
                            if newValue {
                                // Randomize position and scale within bounds
                                // We'll give a margin of 100 on each side
                                let maxX = (geo.size.width / 2) - 100
                                let maxY = (geo.size.height / 2) - 150
                                
                                targetOffset = CGSize(
                                    width: CGFloat.random(in: -maxX...maxX),
                                    height: CGFloat.random(in: -maxY...maxY)
                                )
                                targetScale = CGFloat.random(in: 0.5...1.2)
                            }
                        }
                    }
                } else {
                    VStack(spacing: 30) {
                        Image(systemName: "bolt.heart.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.pink)
                            .padding(.bottom, 20)
                        
                        Text("Task Complete!")
                            .font(.title2.bold())
                        
                        Text("Average Reaction Time: \(Int(calculateAvgRT() * 1000))ms")
                            .font(.title3)
                        
                        if isLoading {
                            ProgressView().padding()
                        } else {
                            Button(action: { route = .home }) {
                                Text("Return to Home").font(.headline)
                            }
                            .buttonStyle(PrimaryButtonStyle())
                        }
                    }
                    .padding(.horizontal, 40)
                }
            }
            
            GlobalBackButton(color: moduleColor(moduleType)) {
                route = .moduleHome(type: moduleType)
            }
            .padding(.leading, 12)
            .padding(.top, 8)
        }
    }

    private func startGame() {
        gameStarted = true
        gameEnded = false
        trialCount = 0
        reactionTimes = []
        scheduleNextTrial()
    }

    private func scheduleNextTrial() {
        showStimulus = false
        let waitTime = Double.random(in: waitRange)
        DispatchQueue.main.asyncAfter(deadline: .now() + waitTime) {
            if gameStarted {
                showStimulus = true
                startTime = Date()
            }
        }
    }

    private func handlePress() {
        guard let start = startTime else { return }
        let reactionTime = Date().timeIntervalSince(start)
        reactionTimes.append(reactionTime)
        
        trialCount += 1
        if trialCount < totalTrials {
            scheduleNextTrial()
        } else {
            finishGame()
        }
    }

    private func finishGame() {
        gameStarted = false
        gameEnded = true
        saveScore()
    }

    private func calculateAvgRT() -> Double {
        guard !reactionTimes.isEmpty else { return 0 }
        return reactionTimes.reduce(0, +) / Double(reactionTimes.count)
    }

    private func saveScore() {
        isLoading = true
        let avgRT = calculateAvgRT()
        
        // Realistic human reaction time bounds
        let baselineRT = 0.3 // 300ms is excellent
        let maxRT = 1.5      // 1.5s is poor
        let range = maxRT - baselineRT
        
        // Calculate score from 0 to 100 based on realistic bounds
        let s = max(0, min(100, ((maxRT - avgRT) / range) * 100))
        
        UserDefaults.standard.set(Float(s), forKey: "\(moduleType)_last_task_score")
        
        isLoading = false
        setTaskDone(moduleType: moduleType)
        checkAndSaveCompletion(moduleType: moduleType, email: session.email)
    }
}
