import SwiftUI

private struct IntroPage {
    let title: String
    let subtitle: String
    let description: String
    let imageName: String
    let color: Color
}

private let pages: [IntroPage] = [
    IntroPage(title: "Welcome to CogniSync",
              subtitle: "Your Mindfulness Journey Begins",
              description: "Discover meditation and cognitive training activities designed to improve your mental clarity and focus.",
              imageName: "brain.head.profile",
              color: Color(hex: "#7C4DFF")),
    IntroPage(title: "Train Your Mind",
              subtitle: "Science-Based Exercises",
              description: "Build focused attention, working memory, and emotional regulation through guided sessions and cognitive tasks.",
              imageName: "bolt.heart.fill",
              color: Color(hex: "#651FFF")),
    IntroPage(title: "Track Your Growth",
              subtitle: "See Real Progress",
              description: "Monitor your improvement across all mental domains with detailed score history and insights.",
              imageName: "chart.line.uptrend.xyaxis",
              color: Color(hex: "#9C27B0")),
]

struct IntroView: View {
    @Binding var route: AppRoute
    @State private var currentPage = 0

    var body: some View {
        ZStack {
            pages[currentPage].color
                .ignoresSafeArea()
                .animation(.easeInOut(duration: 0.4), value: currentPage)

            VStack {
                Spacer()
                TabView(selection: $currentPage) {
                    ForEach(0..<pages.count, id: \.self) { i in
                        IntroPageView(page: pages[i])
                            .tag(i)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                .frame(height: 480)

                // Dots
                HStack(spacing: 8) {
                    ForEach(0..<pages.count, id: \.self) { i in
                        Circle()
                            .fill(currentPage == i ? Color.white : Color.white.opacity(0.4))
                            .frame(width: currentPage == i ? 10 : 7, height: currentPage == i ? 10 : 7)
                            .animation(.spring(), value: currentPage)
                    }
                }
                .padding(.top, 8)

                Spacer()

                // Navigation button
                Button(action: {
                    if currentPage < pages.count - 1 {
                        withAnimation { currentPage += 1 }
                    } else {
                        withAnimation { route = .home }
                    }
                }) {
                    Text(currentPage == pages.count - 1 ? "Get Started" : "Next")
                        .font(.headline)
                }
                .buttonStyle(PrimaryButtonStyle(bgColor: .white.opacity(0.25)))
                .padding(.horizontal, 40)
                .padding(.bottom, 50)
            }
        }
    }
}

private struct IntroPageView: View {
    let page: IntroPage
    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: page.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 110, height: 110)
                .foregroundColor(.white)

            Text(page.title)
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)

            Text(page.subtitle)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white.opacity(0.8))

            Text(page.description)
                .font(.body)
                .foregroundColor(.white.opacity(0.85))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
        }
        .padding()
    }
}
