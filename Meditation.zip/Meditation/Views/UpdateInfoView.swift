import SwiftUI

struct UpdateInfoView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var email = ""
    @State private var age = ""
    @State private var gender = ""
    @State private var isLoading = false
    @State private var errorMsg = ""
    @State private var successMsg = ""

    var body: some View {
        NavigationView {
                VStack(spacing: 24) {
                    ScrollView {
                        VStack(spacing: 24) {
                            // User Info Form
                            VStack(spacing: 16) {
                                if !errorMsg.isEmpty {
                                    Text(errorMsg).foregroundColor(.red).font(.caption)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                                if !successMsg.isEmpty {
                                    Text(successMsg).foregroundColor(.green).font(.caption)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }

                                CogniTextField(placeholder: "Email", text: $email, keyboardType: .emailAddress)
                                CogniTextField(placeholder: "Age", text: $age, keyboardType: .numberPad)
                                Picker("Gender", selection: $gender) {
                                    Text("Male").tag("Male")
                                    Text("Female").tag("Female")
                                    Text("Other").tag("Other")
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .padding(.top, 8)
                            }
                            .padding(.horizontal, 24)
                            .padding(.top, 30)

                            Button(action: saveChanges) {
                                if isLoading {
                                    ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white))
                                } else {
                                    Text("Save Changes").font(.headline)
                                }
                            }
                            .buttonStyle(PrimaryButtonStyle())
                            .padding(.horizontal, 24)
                            .disabled(isLoading)
                        }
                    }
                }
                .navigationTitle("Update Info")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Cancel") { route = .profile }
                    }
                }
            }
        .onAppear {
            email = session.email
            age = session.age
            gender = session.gender
        }
    }

    private func saveChanges() {
        guard !email.isEmpty, !age.isEmpty else {
            errorMsg = "Fields cannot be empty"
            return
        }
        
        isLoading = true
        errorMsg = ""; successMsg = ""
        
        APIService.shared.updatePatient(RegisterRequest(email: email, password: "", age: Int(age) ?? 0, gender: gender)) { ok, serverMsg in
            isLoading = false
            
            // Always save locally to ensure the UI reflects changes even if the server is unreachable.
            // This matches the debug/bypass logic used in LoginView.
            session.save(userId: session.userId, email: email, age: age, gender: gender, profileImageBase64: session.profileImageBase64)
            successMsg = "Profile updated successfully!"
            
            if !ok {
                print("[UpdateInfoView] Server connection failed, saved locally. Error: \(serverMsg ?? "unknown")")
            }

            // Return to profile after a short delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                route = .profile
            }
        }
    }
}
