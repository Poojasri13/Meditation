import SwiftUI

struct HomeView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var modules = ["focused_attention", "working_memory", "present_moment", "cognitive_flexibility", "emotional_regulation"]
    @State private var stats: AssessmentStats?
    @State private var isLoading = false

    var body: some View {
        NavigationView {
                ZStack {
                    LinearGradient(colors: [Color(hex: "#F5F5F7"), Color(.systemBackground)],
                            startPoint: .top, endPoint: .bottom)
                        .ignoresSafeArea()

                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .leading, spacing: 20) {
                            headerView
                            
                            dailyProgressCard
                            
                            if TimetableStore.exists() {
                                timetableCard
                            }
                            
                            Text("Learning Path")
                                .font(.title3.bold())
                                .padding(.horizontal)
                            
                            VStack(spacing: 16) {
                                ForEach(modules, id: \.self) { type in
                                    ModuleCard(moduleType: type) {
                                        route = .moduleHome(type: type)
                                    }
                                }
                            }
                            .padding(.horizontal)
                            
                            // 📊 DYNAMIC PROGRESS GRAPH
                            ModuleProgressGraph(modules: modules)
                                .padding(.horizontal)
                                .padding(.bottom, 30)
                        }
                    }
                }
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        VStack(alignment: .leading, spacing: 0) {
                            Text("CogniSync")
                                .font(.headline)
                                .foregroundColor(Color(hex: "#7C4DFF"))
                            Text("Your Mindful Journey")
                                .font(.caption2)
                                .foregroundColor(.gray)
                        }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        HStack(spacing: 16) {
                            Button(action: { route = .savedProgress }) {
                                Image(systemName: "chart.bar.doc.horizontal.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 24, height: 24)
                                    .foregroundColor(Color(hex: "#7C4DFF"))
                            }
                            
                            Button(action: { route = .profile }) {
                                Group {
                                    if !session.profileImageBase64.isEmpty,
                                       let data = Data(base64Encoded: session.profileImageBase64),
                                       let uiImg = UIImage(data: data) {
                                        Image(uiImage: uiImg)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 32, height: 32)
                                            .clipShape(Circle())
                                            .overlay(Circle().stroke(Color(hex: "#7C4DFF"), lineWidth: 1.5))
                                    } else {
                                        Image(systemName: "person.crop.circle")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 32, height: 32)
                                            .foregroundColor(Color(hex: "#7C4DFF"))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        .onAppear(perform: loadData)
    }

    private var headerView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Hi \(session.username.isEmpty ? "User" : session.username),")
                .font(.system(size: 28, weight: .bold))
            Text("How are you feeling today?")
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding(.top, 10)
        .padding(.horizontal)
    }

    private var dailyProgressCard: some View {
        let assessmentsDone = modules.filter { isAssessmentDone(moduleType: $0) }.count
        let tasksDone = modules.filter { isTaskDone(moduleType: $0) }.count
        
        let completedCount = assessmentsDone + tasksDone
        let totalCount = modules.count * 2 // 1 assessment + 1 task per module
        let progress = totalCount > 0 ? Double(completedCount) / Double(totalCount) : 0
        let percentage = Int(progress * 100)
        
        let timetable = TimetableStore.load()
        let mentalState = timetable?.selected_labels?.first?.label
        let level = timetable?.selected_labels?.first?.level

        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Daily Progress")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("\(completedCount)/\(totalCount) steps completed")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                    
                    if let mentalState = mentalState, let level = level {
                        HStack(spacing: 4) {
                            Image(systemName: "sparkles")
                                .font(.system(size: 8))
                            Text("\(mentalState) (\(level))")
                                .font(.system(size: 10, weight: .bold))
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(8)
                        .padding(.top, 4)
                    }
                }
                Spacer()
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.2), lineWidth: 8)
                    Circle()
                        .trim(from: 0, to: CGFloat(progress))
                        .stroke(Color.white, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                    Text("\(percentage)%")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                }
                .frame(width: 60, height: 60)
            }
            
            Button(action: { route = .savedProgress }) {
                HStack(spacing: 4) {
                    Text("View Saved Progress")
                        .font(.caption.bold())
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .bold))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.white.opacity(0.2))
                .cornerRadius(8)
            }
            .padding(.top, 4)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(LinearGradient(colors: [Color(hex: "#7C4DFF"), Color(hex: "#651FFF")],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
        )
        .padding(.horizontal)
        .shadow(color: Color(hex: "#7C4DFF").opacity(0.3), radius: 10, x: 0, y: 5)
        .onTapGesture {
            route = .savedProgress
        }
    }

    private var timetableCard: some View {
        Button(action: { route = .timetable }) {
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Your 21-Day Journey")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("View your personalized timetable")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                }
                Spacer()
                Image(systemName: "calendar")
                    .font(.system(size: 28))
                    .foregroundColor(.white)
            }
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(LinearGradient(colors: [Color(hex: "#00BCD4"), Color(hex: "#00E5FF")],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
            )
            .padding(.horizontal)
            .shadow(color: Color(hex: "#00BCD4").opacity(0.3), radius: 10, x: 0, y: 5)
        }
        .buttonStyle(PlainButtonStyle())
    }

    private func loadData() {
        // Ensure progress is reset if the day changed while app was in background
        session.checkAndResetDailyProgress()
        
        isLoading = true
        APIService.shared.getAssessmentStats(email: session.email) { s in
            isLoading = false
            self.stats = s
        }
    }
}

// MARK: - Dynamic Graph Component
struct ModuleProgressGraph: View {
    let modules: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Progress Overview")
                .font(.title3.bold())
            
            HStack(alignment: .bottom, spacing: 12) {
                ForEach(modules, id: \.self) { type in
                    VStack {
                        Spacer()
                        if let score = getModuleScore(type: type) {
                            RoundedRectangle(cornerRadius: 6)
                                .fill(LinearGradient(colors: [moduleColor(type), moduleColor(type).opacity(0.7)],
                                                     startPoint: .top, endPoint: .bottom))
                                .frame(height: CGFloat(score) * 1.5) // Scale for UI
                                .overlay(
                                    Text("\(Int(score))%")
                                        .font(.system(size: 8, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(.bottom, 4),
                                    alignment: .bottom
                                )
                        } else {
                            RoundedRectangle(cornerRadius: 6)
                                .fill(Color(.systemGray6))
                                .frame(height: 10) // Small indicator for uncompleted
                        }
                        
                        Text(shortName(type))
                            .font(.system(size: 9))
                            .foregroundColor(.gray)
                            .lineLimit(1)
                            .frame(width: 50)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(height: 180)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color(.secondarySystemBackground).opacity(0.5))
            )
        }
    }
    
    private func getModuleScore(type: String) -> Double? {
        if !isAssessmentDone(moduleType: type) || !isTaskDone(moduleType: type) {
            return nil
        }
        
        // Try to get restored assessment score first
        var assessmentPercent = Double(UserDefaults.standard.float(forKey: "\(type)_last_assessment_score"))
        
        // Fallback to recalculating if it's 0 (meaning maybe not served by sync or fresh session)
        if assessmentPercent == 0 {
            let answers = loadAnswers(moduleType: type)
            let totalScore = answers.values.reduce(0, +)
            assessmentPercent = (Double(totalScore) / 30.0) * 100.0
        }
        
        // Task score is saved in UserDefaults as a Float
        let taskScore = UserDefaults.standard.float(forKey: "\(type)_last_task_score")
        
        // Return combined average
        return (assessmentPercent + Double(taskScore)) / 2.0
    }
    
    private func shortName(_ type: String) -> String {
        switch type {
        case "focused_attention":    return "Attention"
        case "working_memory":       return "Memory"
        case "present_moment":       return "Presence"
        case "cognitive_flexibility": return "Flexibility"
        case "emotional_regulation":  return "Emotion"
        default: return type.capitalized
        }
    }
}

struct ModuleCard: View {
    let moduleType: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 16)
                        .fill(moduleColor(moduleType).opacity(0.1))
                    Image(systemName: moduleIcon(moduleType))
                        .font(.system(size: 24))
                        .foregroundColor(moduleColor(moduleType))
                }
                .frame(width: 56, height: 56)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(moduleTitle(moduleType))
                        .font(.headline)
                        .foregroundColor(.primary)
                    Text("Master your cognitive control")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray.opacity(0.5))
            }
            .padding(16)
            .background(Color(.secondarySystemBackground).opacity(0.5))
            .cornerRadius(20)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    HomeView(route: .constant(.home))
        .environmentObject(UserSession.shared)
}
