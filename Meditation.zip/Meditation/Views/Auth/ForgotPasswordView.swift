import SwiftUI

struct ForgotPasswordView: View {
    @Binding var route: AppRoute
    @State private var email = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    @State private var isLoading = false
    @State private var msg = ""
    @State private var isSuccess = false

    var body: some View {
        VStack(spacing: 0) {
            // Header
            ZStack(alignment: .leading) {
                LinearGradient(colors: [Color(hex:"#7C4DFF"), Color(hex:"#651FFF")],
                               startPoint: .leading, endPoint: .trailing)
                HStack {
                    Button(action: { route = .login }) {
                        Image(systemName: "chevron.left").font(.title3).foregroundColor(.white)
                    }
                    Spacer()
                }
                .padding(.horizontal, 16)
                Text("Reset Password").font(.headline).foregroundColor(.white).frame(maxWidth: .infinity)
            }
            .frame(height: 100)

            VStack(spacing: 20) {
                Spacer().frame(height: 20)

                Image(systemName: "lock.rotation")
                    .resizable().scaledToFit()
                    .frame(width: 70, height: 70)
                    .foregroundColor(Color(hex:"#7C4DFF"))

                Text("Enter your registered email and a new password.")
                    .multilineTextAlignment(.center)
                    .font(.body).foregroundColor(.secondary)
                    .padding(.horizontal, 16)

                CogniTextField(placeholder: "Email address", text: $email, keyboardType: .emailAddress)
                    .padding(.horizontal, 16)

                CogniTextField(placeholder: "New Password (8+ chars, capital, number, special)", text: $newPassword, isSecure: true)
                    .padding(.horizontal, 16)

                CogniTextField(placeholder: "Confirm New Password", text: $confirmPassword, isSecure: true)
                    .padding(.horizontal, 16)

                if !msg.isEmpty {
                    Text(msg)
                        .foregroundColor(isSuccess ? .green : .red)
                        .font(.caption)
                        .padding(.horizontal, 16)
                        .multilineTextAlignment(.center)
                }

                Button(action: resetPassword) {
                    if isLoading {
                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white))
                    } else {
                        Text("Reset Password").font(.headline)
                    }
                }
                .buttonStyle(PrimaryButtonStyle())
                .padding(.horizontal, 16)
                .disabled(isLoading)

                if isSuccess {
                    Button(action: { route = .login }) {
                        Text("Go to Login")
                            .font(.footnote.bold())
                            .foregroundColor(Color(hex:"#7C4DFF"))
                    }
                }

                Spacer()
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(.systemBackground))
    }

    private func resetPassword() {
        let em = email.trimmingCharacters(in: .whitespaces).lowercased()
        let pw = newPassword.trimmingCharacters(in: .whitespaces)
        let cpw = confirmPassword.trimmingCharacters(in: .whitespaces)

        guard !em.isEmpty else { isSuccess = false; msg = "Please enter your email"; return }
        guard !pw.isEmpty, !cpw.isEmpty else { isSuccess = false; msg = "Please fill in both password fields"; return }
        guard pw == cpw else { isSuccess = false; msg = "Passwords do not match"; return }

        // Password strength validation
        let pwRegex = "^[A-Z](?=.*[0-9])(?=.*[\\W_]).{7,}$"
        guard pw.range(of: pwRegex, options: .regularExpression) != nil else {
            isSuccess = false
            msg = "Password must start with capital, 8+ chars, include number & special char"
            return
        }

        isLoading = true; msg = ""
        let body = ["email": em, "new_password": pw]

        var req = URLRequest(url: URL(string: APIService.shared.baseURL + "direct_reset_password.php")!)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONEncoder().encode(body)
        req.timeoutInterval = 30

        URLSession.shared.dataTask(with: req) { data, _, err in
            DispatchQueue.main.async {
                isLoading = false
                if let err = err { isSuccess = false; msg = err.localizedDescription; return }
                guard let data = data,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                    isSuccess = false; msg = "Invalid server response"; return
                }
                if let status = json["status"] as? String, status == "success" {
                    isSuccess = true
                    msg = "Password updated successfully!"
                } else {
                    isSuccess = false
                    msg = json["message"] as? String ?? "Reset failed. Please try again."
                }
            }
        }.resume()
    }
}
