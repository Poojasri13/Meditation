import SwiftUI

struct LoginView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var email = ""
    @State private var password = ""
    @State private var isLoading = false
    @State private var emailErrorMsg = ""
    @State private var passwordErrorMsg = ""

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // Top gradient header
                ZStack {
                    LinearGradient(colors: [Color(hex:"#7C4DFF"), Color(hex:"#651FFF")],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                    VStack(spacing: 10) {
                        Image(systemName: "brain.head.profile")
                            .resizable().scaledToFit()
                            .frame(width: 70, height: 70)
                            .foregroundColor(.white)
                        Text("CogniSync")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                        Text("Sign in to continue")
                            .font(.subheadline).foregroundColor(.white.opacity(0.85))
                    }
                    .padding(.top, 60).padding(.bottom, 40)
                }
                .frame(maxWidth: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 0))

                // Form
                VStack(spacing: 18) {
                    VStack(alignment: .leading, spacing: 5) {
                        CogniTextField(placeholder: "Email", text: $email, keyboardType: .emailAddress)
                            .onChange(of: email) { _ in emailErrorMsg = "" }
                            
                        if !emailErrorMsg.isEmpty {
                            Text(emailErrorMsg)
                                .foregroundColor(.red)
                                .font(.caption)
                                .padding(.leading, 5)
                        }
                    }

                    VStack(alignment: .leading, spacing: 5) {
                        CogniTextField(placeholder: "Password", text: $password, isSecure: true)
                            .onChange(of: password) { _ in passwordErrorMsg = "" }
                            
                        if !passwordErrorMsg.isEmpty {
                            Text(passwordErrorMsg)
                                .foregroundColor(.red)
                                .font(.caption)
                                .padding(.leading, 5)
                        }
                    }

                    Button(action: performLogin) {
                        if isLoading {
                            ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text("Login").font(.headline)
                        }
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(isLoading)

                    Button(action: { route = .forgotPassword }) {
                        Text("Forgot Password?")
                            .font(.footnote)
                            .foregroundColor(Color(hex:"#7C4DFF"))
                    }

                    HStack {
                        Text("Don't have an account?").font(.footnote).foregroundColor(.gray)
                        Button(action: { route = .signup }) {
                            Text("Sign Up").font(.footnote).fontWeight(.bold)
                                .foregroundColor(Color(hex:"#7C4DFF"))
                        }
                    }
                }
                .padding(24)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(.systemBackground))
    }

    private func performLogin() {
        print("[LoginView] performLogin CALLED for \(email)")
        emailErrorMsg = ""
        passwordErrorMsg = ""
        
        let em = email.trimmingCharacters(in: .whitespaces)
        let pw = password.trimmingCharacters(in: .whitespaces)
        
        // 1. Email Format Validation
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        if !emailPred.evaluate(with: em) {
            emailErrorMsg = "Invalid Email! Please enter a valid email address."
            return
        }
        
        isLoading = true
        
        // 2. Email Existence Check
        APIService.shared.getPatientProfile(email: em) { patientProfile in
            guard patientProfile != nil else {
                isLoading = false
                emailErrorMsg = "User not found! This email is not registered."
                return
            }
            
            // 3. Password Validation (Final Step)
            APIService.shared.loginPatient(LoginRequest(email: em, password: pw)) { patient, errMsg in
                isLoading = false
                if let p = patient {
                    print("[LoginView] Login success! Profile: \(p.userId)")
                    session.save(userId: p.userId, email: p.email, age: String(p.age), gender: p.gender, profileImageBase64: p.profile_image ?? "")
                    withAnimation { route = .home }
                } else {
                    print("[LoginView] Login failed: \(errMsg ?? "Unknown error")")
                    passwordErrorMsg = "Incorrect Password! Please try again."
                }
            }
        }
    }
}
