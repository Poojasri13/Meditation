import SwiftUI

struct SignupView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var userId = ""
    @State private var age = ""
    @State private var email = ""
    @State private var password = ""
    @State private var gender = "Select Gender"
    @State private var isLoading = false
    @State private var errorMsg = ""

    let genders = ["Select Gender", "Male", "Female"]

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // Header
                ZStack {
                    LinearGradient(colors: [Color(hex:"#7C4DFF"), Color(hex:"#651FFF")],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                    VStack(spacing: 8) {
                        Image(systemName: "person.crop.circle.badge.plus")
                            .resizable().scaledToFit().frame(width: 60, height: 60).foregroundColor(.white)
                        Text("Create Account").font(.system(size: 26, weight: .bold)).foregroundColor(.white)
                        Text("Start your mindfulness journey").font(.subheadline).foregroundColor(.white.opacity(0.85))
                    }
                    .padding(.top, 60).padding(.bottom, 40)
                }
                .frame(maxWidth: .infinity)

                VStack(spacing: 16) {
                    if !errorMsg.isEmpty {
                        Text(errorMsg).foregroundColor(.red).font(.caption)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    CogniTextField(placeholder: "User ID (5-15 chars, a-z, 0-9, _)", text: $userId)
                    CogniTextField(placeholder: "Age", text: $age, keyboardType: .numberPad)
                    CogniTextField(placeholder: "Email", text: $email, keyboardType: .emailAddress)
                    CogniTextField(placeholder: "Password (8+ chars, capital, number, special)", text: $password, isSecure: true)

                    // Gender Picker
                    HStack {
                        Text(gender).foregroundColor(gender == "Select Gender" ? .gray : .primary)
                        Spacer()
                        Image(systemName: "chevron.down").foregroundColor(.gray)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                    .overlay(
                        Menu {
                            ForEach(genders, id: \.self) { g in
                                Button(g) { gender = g }
                            }
                        } label: { Color.clear }
                    )

                    Button(action: performSignup) {
                        if isLoading {
                            ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else { Text("Sign Up").font(.headline) }
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .disabled(isLoading)

                    HStack {
                        Text("Already have an account?").font(.footnote).foregroundColor(.gray)
                        Button(action: { route = .login }) {
                            Text("Login").font(.footnote).fontWeight(.bold).foregroundColor(Color(hex:"#7C4DFF"))
                        }
                    }
                }
                .padding(24)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(Color(.systemBackground))
    }

    private func performSignup() {
        print("[SignupView] performSignup CALLED")
        let uid = userId.trimmingCharacters(in: .whitespaces) // REMOVED .lowercased()
        let ageStr = age.trimmingCharacters(in: .whitespaces)
        let em = email.trimmingCharacters(in: .whitespaces).lowercased()
        let pw = password.trimmingCharacters(in: .whitespaces)

        print("[SignupView] Checking fields: uid='\(uid)', age='\(ageStr)', email='\(em)', gender='\(gender)'")

        guard gender != "Select Gender" else { 
            print("[SignupView] Validation FAILED: Gender not selected"); 
            errorMsg = "Please select gender"; return 
        }
        guard !uid.isEmpty, !ageStr.isEmpty, !em.isEmpty, !pw.isEmpty else { 
            print("[SignupView] Validation FAILED: Missing fields"); 
            errorMsg = "Please fill all fields"; return 
        }

        // User ID validation (allowed letters, numbers, underscore)
        let uidRegex = "^(?!.*__)(?!(?:admin|support|root|system|null|user)$)[a-zA-Z][a-zA-Z0-9_]{4,14}$"
        guard uid.range(of: uidRegex, options: .regularExpression) != nil else {
            print("[SignupView] Validation FAILED: User ID format invalid ('\(uid)')")
            errorMsg = "User ID: 5-15 chars, start with letter, letters/numbers/underscore only"; return
        }
        // Email
        guard em.contains("@"), em.contains("."), !em.contains(" ") else { 
            print("[SignupView] Validation FAILED: Email format invalid ('\(em)')")
            errorMsg = "Enter a valid email"; return 
        }
        // Password: Starts with capital, at least one number, one special char, 8+ chars total
        let pwRegex = "^[A-Z](?=.*[0-9])(?=.*[\\W_]).{7,}$"
        guard pw.range(of: pwRegex, options: .regularExpression) != nil else {
            print("[SignupView] Validation FAILED: Password format invalid")
            errorMsg = "Password must start with capital, 8+ chars, include number & special char"; return
        }
        guard let ageVal = Int(ageStr), ageVal >= 13, ageVal <= 90 else { 
            print("[SignupView] Validation FAILED: Age invalid ('\(ageStr)')")
            errorMsg = "Age must be 13-90"; return 
        }

        isLoading = true; errorMsg = ""
        print("[SignupView] Fields validated. Registering patient: \(uid)")
        
        let patient = Patient(userId: uid, age: ageVal, gender: gender.lowercased(), email: em, password: pw, profile_image: nil)
        APIService.shared.registerPatient(patient) { ok, errMsg in
            print("[SignupView] API Callback received. ok=\(ok) error=\(errMsg ?? "nil")")
            isLoading = false
            
            if ok {
                print("[SignupView] Success! Redirecting to .intro")
                session.save(userId: uid, email: em, age: ageStr, gender: gender.lowercased())
                withAnimation {
                    route = .intro
                }
            } else {
                print("[SignupView] Failed! Showing error: \(errMsg ?? "Unknown error")")
                errorMsg = errMsg ?? "Registration failed. Please try again."
            }
        }
    }
}

#Preview {
    SignupView(route: .constant(.signup))
        .environmentObject(UserSession.shared)
}
