import SwiftUI

// OtpVerifyView - Deprecated (OTP flow removed)
// This file is kept to prevent build errors from old references.
struct OtpVerifyView: View {
    let email: String
    @Binding var route: AppRoute
    var body: some View { EmptyView() }
}
