import SwiftUI

// ResetPasswordView - Deprecated (OTP flow removed)
// This file is kept to prevent build errors from old references.
struct ResetPasswordView: View {
    let email: String
    let otp: String
    @Binding var route: AppRoute
    var body: some View { EmptyView() }
}
