import SwiftUI

struct TimetableListView: View {
    @Binding var route: AppRoute
    @State private var timetable: [TimetableItem] = []
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Your 21-Day Timetable")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.primary)
                
                Spacer()
                
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            .padding(.bottom, 10)
            
            if timetable.isEmpty {
                VStack(spacing: 20) {
                    Spacer()
                    Image(systemName: "calendar.badge.exclamationmark")
                        .font(.system(size: 60))
                        .foregroundColor(.secondary.opacity(0.3))
                    
                    Text("No timetable found.")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    
                    Button("Start Assessment") {
                        route = .nBack // Start from the first cognitive task
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.purple)
                    Spacer()
                }
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(timetable.enumerated()), id: \.offset) { index, item in
                            Button {
                                route = .session(
                                    audioURL: item.audio_code, // Note: In Android, it seems audio_code might be the ID/URL
                                    audioTitle: item.title,
                                    audioDesc: item.description,
                                    index: index
                                )
                            } label: {
                                TimetableRow(day: index + 1, item: item)
                                    .padding(.horizontal, 20)
                            }
                            
                            if index < timetable.count - 1 {
                                Divider()
                                    .padding(.leading, 80)
                            }
                        }
                    }
                    .padding(.vertical, 10)
                }
                
                Button {
                    route = .home
                } label: {
                    Text("Done")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.purple)
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 20)
                }
            }
        }
        .background(Color(UIColor.systemBackground))
        .onAppear {
            if let saved = TimetableStore.load() {
                self.timetable = saved.timetable ?? []
            }
        }
    }
}

#Preview {
    TimetableListView(route: .constant(.home))
}
