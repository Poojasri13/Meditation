import SwiftUI

struct SplashView: View {
    @EnvironmentObject var session: UserSession
    @Binding var appRoute: AppRoute

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(hex: "#7C4DFF"), Color(hex: "#651FFF")],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 16) {
                Image(systemName: "brain.head.profile")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.white)
                Text("CogniSync")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.white)
                Text("Mindfulness & Cognitive Training")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                withAnimation {
                    appRoute = .login
                }
            }
        }
    }
}
