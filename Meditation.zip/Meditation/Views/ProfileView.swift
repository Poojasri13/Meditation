import SwiftUI
import PhotosUI

struct ProfileView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession
    @State private var showNotificationAlert = false

    @State private var minsTrained: Int = 0
    @State private var streakDays: Int = 0
    @State private var efficiency: Int = 0

    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var profileImage: UIImage? = nil
    @State private var isUploadingProfileImage = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Profile Header
                    VStack(spacing: 12) {
                        PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                            ZStack(alignment: .bottomTrailing) {
                                if let image = profileImage {
                                    Image(uiImage: image)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 80, height: 80)
                                        .clipShape(Circle())
                                        .overlay(Circle().stroke(Color(hex: "#7C4DFF"), lineWidth: 2))
                                } else if !session.profileImageBase64.isEmpty,
                                          let data = Data(base64Encoded: session.profileImageBase64),
                                          let image = UIImage(data: data) {
                                    Image(uiImage: image)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 80, height: 80)
                                        .clipShape(Circle())
                                        .overlay(Circle().stroke(Color(hex: "#7C4DFF"), lineWidth: 2))
                                        .onAppear {
                                            self.profileImage = image
                                        }
                                } else {
                                    Image(systemName: "person.crop.circle.fill")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 80, height: 80)
                                        .foregroundColor(Color(hex: "#7C4DFF"))
                                }
                                
                                Image(systemName: "camera.circle.fill")
                                    .resizable()
                                    .frame(width: 24, height: 24)
                                    .foregroundColor(.white)
                                    .background(Circle().fill(Color.blue))
                                    .offset(x: 2, y: 2)
                            }
                        }
                        .disabled(isUploadingProfileImage)
                        .onChange(of: selectedPhotoItem) { newItem in
                            Task {
                                await updateProfileImage(newItem: newItem)
                            }
                        }
                        
                        if isUploadingProfileImage {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: Color(hex: "#7C4DFF")))
                                .padding(.top, 4)
                                .frame(height: 10)
                        }
                        
                        Text(session.email)
                            .font(.headline)
                        
                        Text("Goal: Mindful Clarity")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.top, 20)

                    // Stats Grid
                    HStack(spacing: 16) {
                        ProfileStatItem(title: "Mins Trained", val: "\(minsTrained)", icon: "clock.fill", color: .blue)
                        ProfileStatItem(title: "Streak", val: "\(streakDays) Days", icon: "flame.fill", color: .orange)
                        ProfileStatItem(title: "Efficiency", val: "\(efficiency)%", icon: "bolt.fill", color: .purple)
                    }
                    .padding(.horizontal)

                    // Settings Group
                    VStack(spacing: 1) {
                        ProfileRow(icon: "pencil.and.outline", title: "Update Profile Info", color: .blue) {
                            route = .updateInfo
                        }
                        ProfileRow(icon: "arrow.counterclockwise", title: "Reset Progress", color: .orange) {
                            route = .resetAccount
                        }
                        ProfileRow(icon: "bell.fill", title: "Notifications", color: .green) {
                            showNotificationAlert = true
                        }
                        ProfileRow(icon: "shield.fill", title: "Privacy", color: .gray) {
                            route = .privacy
                        }
                    }
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(12)
                    .padding(.horizontal)

                    // Logout
                    Button(action: {
                        session.signOut()
                        route = .login
                    }) {
                        HStack {
                            Image(systemName: "power")
                            Text("Log Out")
                        }
                        .foregroundColor(.red)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                }
            }
            .alert(isPresented: $showNotificationAlert) {
                Alert(
                    title: Text("Mindful Reminder 🌸"),
                    message: Text("Pause. Breathe. Reset.\nA few mindful minutes can transform your entire day."),
                    dismissButton: .default(Text("OK"))
                )
            }
            .onAppear {
                calculateStats()
            }
            .navigationTitle("Profile")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: { route = .home }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(Color(hex: "#7C4DFF"))
                        Text("Home").foregroundColor(Color(hex: "#7C4DFF"))
                    }
                }
            }
        }
    }
    
    private func calculateStats() {
        let records = getLocalSavedProgress()
        
        // Mins Trained (assume 15 mins per module)
        minsTrained = records.count * 15
        
        // Efficiency
        if records.isEmpty {
            efficiency = 0
        } else {
            let totalEfficiency = records.reduce(0.0) { $0 + ($1.percentageScore + $1.taskScore) / 2.0 }
            efficiency = Int(totalEfficiency / Float(records.count))
        }
        
        // Streak
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        
        let dates = records.compactMap { formatter.date(from: $0.completionDate) }
            .map { Calendar.current.startOfDay(for: $0) }
        
        let uniqueDates = Array(Set(dates)).sorted(by: >)
        
        guard !uniqueDates.isEmpty else {
            streakDays = 0
            return
        }
        
        let today = Calendar.current.startOfDay(for: Date())
        var currentStreak = 0
        var dateToCheck = today
        
        if !uniqueDates.contains(today) {
            if let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: today),
               uniqueDates.contains(yesterday) {
                dateToCheck = yesterday
            } else {
                streakDays = 0
                return
            }
        }
        
        for date in uniqueDates {
            if date == dateToCheck {
                currentStreak += 1
                dateToCheck = Calendar.current.date(byAdding: .day, value: -1, to: dateToCheck)!
            } else {
                break
            }
        }
        
        streakDays = currentStreak
    }
    
    private func updateProfileImage(newItem: PhotosPickerItem?) async {
        guard let item = newItem else { return }
        isUploadingProfileImage = true
        
        if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) {
            // Compress image to Base64 to save upload payload size.
            if let compressedData = image.jpegData(compressionQuality: 0.5) {
                let base64String = compressedData.base64EncodedString()
                DispatchQueue.main.async {
                    self.profileImage = image
                }
                
                APIService.shared.updateUserProfile(["email": session.email, "profile_image": base64String]) { success in
                    DispatchQueue.main.async {
                        if success {
                            session.save(userId: session.userId, email: session.email, age: session.age, gender: session.gender, profileImageBase64: base64String)
                            print("[ProfileView] Profile Image Updated To Backend Successfully.")
                        } else {
                            print("[ProfileView] Profile Image Update Failed.")
                        }
                        isUploadingProfileImage = false
                    }
                }
            } else {
                isUploadingProfileImage = false
            }
        } else {
            isUploadingProfileImage = false
        }
    }
}

struct ProfileStatItem: View {
    let title: String
    let val: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(color)
            Text(val)
                .font(.headline)
            Text(title)
                .font(.caption2)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color(.secondarySystemBackground).opacity(0.5))
        .cornerRadius(16)
    }
}

struct ProfileRow: View {
    let icon: String
    let title: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                Image(systemName: icon)
                    .foregroundColor(color)
                    .frame(width: 24)
                Text(title)
                    .foregroundColor(.primary)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color(.secondarySystemBackground).opacity(0.5))
        }
    }
}

struct PrivacyView: View {
    @Binding var route: AppRoute
    @State private var showDeleteAlert = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    
                    Text("Privacy & Data Protection 🔒")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color(hex: "#7C4DFF"))
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top, 20)
                    
                    VStack(alignment: .leading, spacing: 12) {
                        PrivacySection(
                            title: "1. What Data We Collect",
                            text: "We collect only essential information such as your email address, meditation session time, streak data, efficiency score, and progress statistics to provide a personalized experience."
                        )
                        
                        PrivacySection(
                            title: "2. How We Use Your Data",
                            text: "Your data is used only to track your meditation progress, maintain streaks, calculate efficiency, and improve your overall mindfulness journey."
                        )
                        
                        PrivacySection(
                            title: "3. Data Security",
                            text: "Your information is securely stored and protected. We do not share, sell, or distribute your personal data to third parties."
                        )
                        
                        PrivacySection(
                            title: "4. Notification Usage",
                            text: "Notifications are used only to send meditation reminders, progress updates, and motivational messages to support your consistency."
                        )
                    }
                    .padding(.horizontal)
                    
                    Button(action: {
                        showDeleteAlert = true
                    }) {
                        Text("Delete My Account")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red.opacity(0.9))
                            .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    .padding(.bottom, 40)
                    
                }
            }
            .background(Color(.systemBackground))
            .alert(isPresented: $showDeleteAlert) {
                Alert(
                    title: Text("Confirm Deletion"),
                    message: Text("Are you sure you want to delete your account? This action cannot be undone."),
                    primaryButton: .destructive(Text("Delete")) {
                        // Action for delete if any
                    },
                    secondaryButton: .cancel()
                )
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: { route = .profile }) { // Assuming back goes to profile
                        Image(systemName: "chevron.left")
                            .foregroundColor(Color(hex: "#7C4DFF"))
                        Text("Profile").foregroundColor(Color(hex: "#7C4DFF"))
                    }
                }
            }
        }
    }
}

struct PrivacySection: View {
    let title: String
    let text: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
            
            Text(text)
                .font(.body)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.bottom, 10)
    }
}
