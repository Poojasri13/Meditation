import SwiftUI

struct ProgressAttempt: Identifiable {
    let id = UUID()
    let displayTitle: String
    let date: String
    let records: [ModuleCompletionRecord]
}

struct SavedProgressView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession
    
    @State private var attempts: [ProgressAttempt] = []
    @State private var isLoading = false
    @State private var selectedAttempt: ProgressAttempt? = nil
    
    private let modules = ["focused_attention", "working_memory", "present_moment", "cognitive_flexibility", "emotional_regulation"]
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            Color(.systemBackground).ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    Spacer().frame(height: 60)
                    
                    // Header
                    VStack(alignment: .leading, spacing: 8) {
                        Text("📊 Tasks Overview")
                            .font(.title2.bold())
                        
                        if let attempt = selectedAttempt {
                            Text(attempt.displayTitle)
                                .font(.headline)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.horizontal)
                    
                    if isLoading {
                        ProgressView()
                            .frame(maxWidth: .infinity, minHeight: 200)
                    } else if attempts.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "tray.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.gray.opacity(0.3))
                            Text("No progress saved yet.")
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity, minHeight: 400)
                    } else {
                        if let attempt = selectedAttempt {
                            // Show results for selected attempt
                            VStack(spacing: 20) {
                                Button(action: { selectedAttempt = nil }) {
                                    HStack {
                                        Image(systemName: "chevron.left")
                                        Text("Back to saved sessions")
                                    }
                                    .font(.subheadline)
                                    .foregroundColor(.blue)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.bottom, 8)
                                
                                ForEach(modules, id: \.self) { type in
                                    let record = attempt.records.first(where: { $0.moduleType == type })
                                    ModuleProgressRow(moduleType: type, record: record)
                                }
                            }
                            .padding(.horizontal)
                        } else {
                            // Show list of attempts
                            VStack(alignment: .leading, spacing: 16) {
                                Text("Select a session to view progress:")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                    .padding(.bottom, 8)
                                
                                ForEach(attempts) { attempt in
                                    Button(action: { selectedAttempt = attempt }) {
                                        HStack {
                                            VStack(alignment: .leading, spacing: 4) {
                                                Text(attempt.displayTitle)
                                                    .font(.headline)
                                                    .foregroundColor(.primary)
                                                
                                                let count = attempt.records.count
                                                Text(count == 5 ? "All Tasks Completed" : "Not Completed (\(count)/5)")
                                                    .font(.caption)
                                                    .foregroundColor(count == 5 ? .green : .red)
                                            }
                                            
                                            Spacer()
                                            
                                            Image(systemName: "chevron.right")
                                                .foregroundColor(.gray)
                                        }
                                        .padding()
                                        .background(Color(.secondarySystemBackground).opacity(0.5))
                                        .cornerRadius(12)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    Spacer().frame(height: 40)
                }
            }
            
            GlobalBackButton(color: .primary) {
                route = .home
            }
            .padding(.leading, 12)
            .padding(.top, 8)
        }
        .onAppear(perform: loadProgress)
    }
    
    private func loadProgress() {
        isLoading = true
        let allRecords = getLocalSavedProgress()
        
        let dict = Dictionary(grouping: allRecords, by: { $0.completionDate })
        var parsedAttempts: [ProgressAttempt] = []
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let sortedDates = dict.keys.sorted { d1, d2 in
            let date1 = formatter.date(from: d1) ?? Date.distantPast
            let date2 = formatter.date(from: d2) ?? Date.distantPast
            return date1 > date2
        }
        
        for dateStr in sortedDates {
            // Newest first inherently from db sorting
            let recordsForDate = dict[dateStr] ?? []
            
            // To properly group them into dense buckets chronologically, traverse from oldest to newest:
            var buckets: [[ModuleCompletionRecord]] = []
            
            // Reversing makes it oldest first
            for rec in recordsForDate.reversed() {
                var placed = false
                for i in 0..<buckets.count {
                    if !buckets[i].contains(where: { $0.moduleType == rec.moduleType }) {
                        buckets[i].append(rec)
                        placed = true
                        break
                    }
                }
                if !placed {
                    buckets.append([rec])
                }
            }
            
            // Filter out any incomplete buckets (only show fully completed 5/5 sessions)
            let fullyCompletedBuckets = buckets.filter { $0.count == 5 }
            
            let totalSessions = fullyCompletedBuckets.count
            // Traverse buckets backwards to show Newest attempt at the top of the UI
            for index in (0..<totalSessions).reversed() {
                let sessionRecords = fullyCompletedBuckets[index]
                let attemptNumber = index + 1
                let title = totalSessions > 1 ? "\(dateStr)-\(attemptNumber)" : dateStr
                parsedAttempts.append(ProgressAttempt(displayTitle: title, date: dateStr, records: sessionRecords))
            }
        }
        
        self.attempts = parsedAttempts
        self.isLoading = false
    }
}

struct ModuleProgressRow: View {
    let moduleType: String
    let record: ModuleCompletionRecord?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: moduleIcon(moduleType))
                    .foregroundColor(moduleColor(moduleType))
                    .frame(width: 32)
                
                Text(moduleTitle(moduleType))
                    .font(.headline)
                
                Spacer()
                
                if record != nil {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundColor(.blue)
                }
            }
            
            if let record = record {
                HStack(spacing: 20) {
                    StatBox(title: "Percentage", val: "\(Int(record.percentageScore))%", color: moduleColor(moduleType))
                    StatBox(title: "Daily Progress", val: "\(Int(record.dailyProgress))%", color: .blue)
                    StatBox(title: "Task Score", val: "\(Int(record.taskScore))%", color: .orange)
                }
                
                // Simple graphical representation
                HStack(spacing: 4) {
                    ForEach(0..<10) { i in
                        RoundedRectangle(cornerRadius: 2)
                            .fill(i < Int(record.dailyProgress / 10) ? moduleColor(moduleType) : Color(.systemGray6))
                            .frame(height: 8)
                    }
                }
                .padding(.top, 8)
            } else {
                Text("Not completed today")
                    .font(.caption)
                    .foregroundColor(.gray)
                    .italic()
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground).opacity(0.5))
        .cornerRadius(16)
    }
}

struct StatBox: View {
    let title: String
    let val: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(val)
                .font(.subheadline.bold())
                .foregroundColor(color)
            Text(title)
                .font(.system(size: 10))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
