import SwiftUI

struct TaskSwitchView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var currentNumber = 0
    @State private var currentTask: TaskType = .oddEven
    @State private var score = 0
    @State private var trialCount = 0
    @State private var gameStarted = false
    @State private var gameEnded = false
    @State private var isLoading = false
    @State private var responseGiven = false

    private let totalTrials = 15

    enum TaskType {
        case oddEven // Square cue
        case range // Circle cue
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color(.systemBackground).ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer().frame(height: 40)
                if !gameStarted && !gameEnded {
                    VStack(spacing: 20) {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.system(size: 80))
                            .foregroundColor(moduleColor("emotional_regulation"))
                            .padding(.bottom, 20)
                        
                        Text("Task Switching Challenge")
                            .font(.title2.bold())
                        
                        Text("Rule 1 (SQUARE): Is the number Odd or Even?\nRule 2 (CIRCLE): Is the number > 5 or < 5?")
                            .font(.subheadline).foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                        
                        Button(action: startGame) {
                            Text("Start Task").font(.headline)
                        }
                        .buttonStyle(PrimaryButtonStyle(bgColor: moduleColor("emotional_regulation")))
                    }
                    .padding(.horizontal, 40)
                } else if gameStarted && !gameEnded {
                    VStack(spacing: 40) {
                        Text("Trial \(trialCount + 1) of \(totalTrials)")
                            .font(.caption).foregroundColor(.gray)
                        
                        // Cue
                        VStack(spacing: 20) {
                            if currentTask == .oddEven {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.blue.opacity(0.1))
                                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.blue, lineWidth: 4))
                                    .frame(width: 80, height: 80)
                                Text("ODD OR EVEN?").font(.headline).foregroundColor(.blue)
                            } else {
                                Circle()
                                    .fill(Color.orange.opacity(0.1))
                                    .overlay(Circle().stroke(Color.orange, lineWidth: 4))
                                    .frame(width: 80, height: 80)
                                Text("> 5 OR < 5?").font(.headline).foregroundColor(.orange)
                            }
                        }
                        
                        Text("\(currentNumber)")
                            .font(.system(size: 100, weight: .bold))
                            .transition(.scale)
                            .id(trialCount)
                        
                        HStack(spacing: 20) {
                            if currentTask == .oddEven {
                                Button(action: { handlePress(true) }) {
                                    Text("ODD")
                                        .font(.headline)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.blue)
                                        .foregroundColor(.white)
                                        .cornerRadius(12)
                                }
                                Button(action: { handlePress(false) }) {
                                    Text("EVEN")
                                        .font(.headline)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.blue.opacity(0.1))
                                        .foregroundColor(.blue)
                                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.blue, lineWidth: 2))
                                }
                            } else {
                                Button(action: { handlePress(true) }) {
                                    Text("> 5")
                                        .font(.headline)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.orange)
                                        .foregroundColor(.white)
                                        .cornerRadius(12)
                                }
                                Button(action: { handlePress(false) }) {
                                    Text("< 5")
                                        .font(.headline)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.orange.opacity(0.1))
                                        .foregroundColor(.orange)
                                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.orange, lineWidth: 2))
                                }
                            }
                        }
                        .padding(.horizontal, 40)
                    }
                    .transition(.opacity)
                } else {
                    VStack(spacing: 30) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.green)
                            .padding(.bottom, 20)
                        
                        Text("Task Complete!")
                            .font(.title2.bold())
                        
                        Text("Final Score: \(Int(calculateScore()))%")
                            .font(.title3)
                        
                        if isLoading {
                            ProgressView().padding()
                        } else {
                            Button(action: { route = .home }) {
                                Text("Return to Home").font(.headline)
                            }
                            .buttonStyle(PrimaryButtonStyle())
                        }
                    }
                    .padding(.horizontal, 40)
                }
            }
            
            GlobalBackButton(color: moduleColor("emotional_regulation")) {
                route = .moduleHome(type: "emotional_regulation")
            }
            .padding(.leading, 12)
            .padding(.top, 8)
        }
    }

    private func startGame() {
        gameStarted = true
        gameEnded = false
        score = 0
        trialCount = 0
        showNextTrial()
    }

    private func showNextTrial() {
        currentNumber = Int.random(in: 1...9)
        if currentNumber == 5 { currentNumber = 4 } // Avoid 5 to prevent confusion with range task
        currentTask = Bool.random() ? .oddEven : .range
        responseGiven = false
    }

    private func handlePress(_ option: Bool) {
        guard !responseGiven else { return }
        responseGiven = true
        
        var correct = false
        if currentTask == .oddEven {
            correct = (currentNumber % 2 != 0) == option
        } else {
            correct = (currentNumber > 5) == option
        }
        
        if correct { score += 1 }
        
        trialCount += 1
        if trialCount < totalTrials {
            showNextTrial()
        } else {
            finishGame()
        }
    }

    private func finishGame() {
        gameStarted = false
        gameEnded = true
        saveScore()
    }

    private func calculateScore() -> Float {
        guard totalTrials > 0 else { return 100 }
        return Float(score) / Float(totalTrials) * 100
    }

    private func saveScore() {
        isLoading = true
        let s = calculateScore()
        UserDefaults.standard.set(s, forKey: "emotional_regulation_last_task_score")
        
        isLoading = false
        setTaskDone(moduleType: "emotional_regulation")
        checkAndSaveCompletion(moduleType: "emotional_regulation", email: session.email)
    }
}
