import SwiftUI

struct TimetableRow: View {
    let day: Int
    let item: TimetableItem
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            // Day Circle
            ZStack {
                Circle()
                    .fill(Color.purple.opacity(0.1))
                    .frame(width: 45, height: 45)
                
                Text("\(day)")
                    .font(.headline)
                    .foregroundColor(.purple)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundColor(.primary)
                
                Text(item.description)
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
                    .lineLimit(2)
                
                Text(item.module.replacingOccurrences(of: "_", with: " ").capitalized)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.purple)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.purple.opacity(0.1))
                    .cornerRadius(4)
                    .padding(.top, 4)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.secondary.opacity(0.5))
        }
        .padding(.vertical, 10)
    }
}

#Preview {
    TimetableRow(day: 1, item: TimetableItem(audio_code: "A1", module: "focused_attention", title: "Introduction to Focus", description: "A short 5-minute session to get you started with focused attention meditation."))
        .padding()
}
