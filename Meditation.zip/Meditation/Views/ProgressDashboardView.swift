import SwiftUI

struct ProgressDashboardView: View {
    let scoreType: String
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var scoreHistory: [ScoreResponse] = []
    @State private var isLoading = false

    var body: some View {
        NavigationView {
                VStack {
                        if isLoading {
                            ProgressView()
                        } else if scoreHistory.isEmpty {
                            VStack(spacing: 20) {
                                Image(systemName: "chart.bar.xaxis")
                                    .font(.system(size: 60))
                                    .foregroundColor(.gray.opacity(0.3))
                                Text("No progress recorded yet.")
                                    .font(.subheadline).foregroundColor(.gray)
                            }
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                        } else {
                            List(scoreHistory, id: \.createdAt) { item in
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(item.createdAt ?? "Unknown date")
                                            .font(.caption).foregroundColor(.gray)
                                        Text("Score: \(Int(item.score))%")
                                            .font(.headline)
                                    }
                                    Spacer()
                                    ProgressView(value: Double(item.score), total: 100)
                                        .frame(width: 80)
                                }
                                .padding(.vertical, 8)
                            }
                        }
                }
                .navigationTitle("\(moduleTitle(scoreType)) History")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Done") { route = .home }
                    }
                }
            }
        .onAppear(perform: loadHistory)
    }

    private func loadHistory() {
        isLoading = true
        APIService.shared.getScoreHistory(email: session.email, domain: scoreType) { history in
            isLoading = false
            self.scoreHistory = history
        }
    }
}
