import SwiftUI

struct SARTView: View {
    @Binding var route: AppRoute
    @EnvironmentObject var session: UserSession

    @State private var sequence: [Int] = []
    @State private var currentIndex = 0
    @State private var score = 0
    @State private var gameStarted = false
    @State private var gameEnded = false
    @State private var currentStimulus: Int?
    @State private var responseGiven = false
    @State private var isLoading = false

    private let targetDigit = 3
    private let totalTrials = 20
    private let stimulusInterval: TimeInterval = 1.0 // seconds

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color(.systemBackground).ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer().frame(height: 40)
                if !gameStarted && !gameEnded {
                    VStack(spacing: 20) {
                        Image(systemName: "scope")
                            .font(.system(size: 80))
                            .foregroundColor(moduleColor("working_memory"))
                            .padding(.bottom, 20)
                        
                        Text("SART Challenge")
                            .font(.title2.bold())
                        
                        Text("Press the button for every digit EXCEPT for the digit '3'.")
                            .font(.subheadline).foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                        
                        Button(action: startGame) {
                            Text("Start Task").font(.headline)
                        }
                        .buttonStyle(PrimaryButtonStyle(bgColor: moduleColor("working_memory")))
                    }
                    .padding(.horizontal, 40)
                } else if gameStarted && !gameEnded {
                    VStack(spacing: 40) {
                        Text("Trial \(currentIndex + 1) of \(totalTrials)")
                            .font(.caption).foregroundColor(.gray)
                        
                        if let stimulus = currentStimulus {
                            Text("\(stimulus)")
                                .font(.system(size: 100, weight: .bold))
                                .foregroundColor(.primary)
                                .transition(.scale)
                                .id(currentIndex)
                        }
                        
                        Button(action: handlePress) {
                            Text("PRESS")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color(hex: "#00BCD4"))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }
                        .disabled(responseGiven)
                        .padding(.horizontal, 60)
                    }
                } else {
                    VStack(spacing: 30) {
                        Image(systemName: "medal.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.orange)
                            .padding(.bottom, 20)
                        
                        Text("Task Complete!")
                            .font(.title2.bold())
                        
                        Text("Your score: \(Int(calculateScore()))%")
                            .font(.title3)
                            .foregroundColor(moduleColor("working_memory"))
                        
                        if isLoading {
                            ProgressView().padding()
                        } else {
                            Button(action: { route = .home }) {
                                Text("Return to Home").font(.headline)
                            }
                            .buttonStyle(PrimaryButtonStyle())
                        }
                    }
                    .padding(.horizontal, 40)
                }
            }
            
            GlobalBackButton(color: moduleColor("working_memory")) {
                route = .moduleHome(type: "working_memory")
            }
            .padding(.leading, 12)
            .padding(.top, 8)
        }
    }

    private func startGame() {
        sequence = (0..<totalTrials).map { _ in Int.random(in: 1...9) }
        score = 0
        gameStarted = true
        gameEnded = false
        currentIndex = 0
        showNextStimulus()
    }

    private func showNextStimulus() {
        if currentIndex < totalTrials {
            currentStimulus = sequence[currentIndex]
            responseGiven = false
            
            DispatchQueue.main.asyncAfter(deadline: .now() + stimulusInterval) {
                // If it was the target digit (3) and they correctly ignored it, reward them
                if !responseGiven && currentStimulus == targetDigit {
                    score += 1
                }
                
                if currentIndex < totalTrials - 1 {
                    currentIndex += 1
                    showNextStimulus()
                } else {
                    finishGame()
                }
            }
        }
    }

    private func handlePress() {
        guard !responseGiven else { return }
        responseGiven = true
        
        if currentStimulus != targetDigit {
            // Correct press on non-target
            score += 1
        }
    }

    private func finishGame() {
        gameStarted = false
        gameEnded = true
        saveScore()
    }

    private func calculateScore() -> Float {
        guard totalTrials > 0 else { return 100 }
        return Float(score) / Float(totalTrials) * 100
    }

    private func saveScore() {
        isLoading = true
        let s = calculateScore()
        UserDefaults.standard.set(s, forKey: "working_memory_last_task_score")
        
        isLoading = false
        setTaskDone(moduleType: "working_memory")
        checkAndSaveCompletion(moduleType: "working_memory", email: session.email)
    }
}
