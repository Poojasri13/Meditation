import Foundation

class TimetableStore {
    private static let key = "cognisync_timetable_json"
    
    static func save(_ response: MLPredictResponse) {
        if let data = try? JSONEncoder().encode(response) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
    
    static func load() -> MLPredictResponse? {
        if let data = UserDefaults.standard.data(forKey: key) {
            return try? JSONDecoder().decode(MLPredictResponse.self, from: data)
        }
        return nil
    }
    
    static func exists() -> Bool {
        return UserDefaults.standard.data(forKey: key) != nil
    }
    
    static func clear() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}
