import SwiftUI

// Hex color init
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(.sRGB, red: Double(r)/255, green: Double(g)/255, blue: Double(b)/255, opacity: Double(a)/255)
    }
}

// Reusable primary button style
struct PrimaryButtonStyle: ButtonStyle {
    var bgColor: Color = Color(hex: "#7C4DFF")
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(bgColor)
            .cornerRadius(12)
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.easeInOut(duration: 0.15), value: configuration.isPressed)
    }
}

// Reusable text field style
struct CogniTextField: View {
    var placeholder: String
    @Binding var text: String
    var isSecure: Bool = false
    var keyboardType: UIKeyboardType = .default

    @State private var showPassword = false

    var body: some View {
        ZStack(alignment: .trailing) {
            Group {
                if isSecure && !showPassword {
                    SecureField(placeholder, text: $text)
                        .keyboardType(keyboardType)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                } else {
                    TextField(placeholder, text: $text)
                        .keyboardType(keyboardType)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(10)

            if isSecure {
                Button(action: { showPassword.toggle() }) {
                    Image(systemName: showPassword ? "eye" : "eye.slash")
                        .foregroundColor(.gray)
                }
                .padding(.trailing, 14)
            }
        }
    }
}

// Module color helper
func moduleColor(_ type: String) -> Color {
    switch type {
    case "focused_attention":    return Color(hex: "#7C4DFF")
    case "working_memory":       return Color(hex: "#00BCD4")
    case "present_moment", "present_moment_awareness": return Color(hex: "#4CAF50")
    case "cognitive_flexibility": return Color(hex: "#FF9800")
    case "emotional_regulation":  return Color(hex: "#E91E63")
    default: return Color(hex: "#7C4DFF")
    }
}

func moduleTitle(_ type: String) -> String {
    switch type {
    case "focused_attention":    return "Focused Attention"
    case "working_memory":       return "Working Memory"
    case "present_moment", "present_moment_awareness": return "Present Moment"
    case "cognitive_flexibility": return "Cognitive Flexibility"
    case "emotional_regulation":  return "Emotional Regulation"
    default: return type.capitalized
    }
}

func moduleIcon(_ type: String) -> String {
    switch type {
    case "focused_attention":    return "scope"
    case "working_memory":       return "brain.head.profile"
    case "present_moment", "present_moment_awareness": return "leaf.fill"
    case "cognitive_flexibility": return "arrow.triangle.2.circlepath"
    case "emotional_regulation":  return "heart.fill"
    default: return "star.fill"
    }
}

// Global Back Button component
struct GlobalBackButton: View {
    var color: Color = .primary
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 18, weight: .semibold))
                Text("Back")
                    .font(.system(size: 17))
            }
            .foregroundColor(color)
            .padding(.vertical, 8)
            .padding(.horizontal, 12)
            .background(Color(.systemBackground).opacity(0.01)) // Increase tap area
        }
    }
}
