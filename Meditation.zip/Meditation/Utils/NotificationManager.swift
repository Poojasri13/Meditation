import Foundation
import UserNotifications

// MARK: - NotificationManager
// Manages a single 24-hour "Mindful Reminder" notification tied to task completion.
class NotificationManager {

    static let shared = NotificationManager()
    private init() {}

    // The fixed identifier for the 24-hour reminder. Only one can exist at a time.
    private let reminderID = "mindful_24hr_reminder"

    // UserDefaults key for storing the last completion timestamp
    private let completionTimestampKey = "last_task_completion_timestamp"

    // MARK: - Permission

    /// Request notification permission from the user. Call once at app launch.
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error = error {
                print("[NotificationManager] Auth error: \(error.localizedDescription)")
            } else {
                print("[NotificationManager] Notification permission granted: \(granted)")
            }
        }
    }

    // MARK: - Schedule

    /// Call this whenever a task/session is completed.
    /// Cancels any existing reminder and schedules a fresh one 24 hours later.
    func scheduleReminder() {
        // 1. Store the current completion timestamp
        let now = Date()
        UserDefaults.standard.set(now.timeIntervalSince1970, forKey: completionTimestampKey)

        // 2. Cancel any existing 24-hour reminder
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [reminderID])

        // 3. Build the notification content
        let content = UNMutableNotificationContent()
        content.title = "Mindful Reminder 🌸"
        content.body = "Pause. Breathe. Reset.\nA few mindful minutes can transform your entire day."
        content.sound = .default

        // 4. Trigger exactly 24 hours (86400 seconds) later
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 86400, repeats: false)

        // 5. Schedule the notification
        let request = UNNotificationRequest(identifier: reminderID, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("[NotificationManager] Failed to schedule reminder: \(error.localizedDescription)")
            } else {
                print("[NotificationManager] 24-hour reminder scheduled for \(now.addingTimeInterval(86400))")
            }
        }
    }

    // MARK: - App-Open Check

    /// Call this when the app becomes active/foreground.
    /// If 24 or more hours have passed since the last task completion AND the
    /// pending notification was not yet delivered (e.g. app was open the whole time),
    /// deliver the notification immediately via an in-app alert-style local notification.
    func checkAndDeliverIfOverdue() {
        let lastTimestamp = UserDefaults.standard.double(forKey: completionTimestampKey)
        guard lastTimestamp > 0 else { return }  // No completion recorded yet

        let lastDate = Date(timeIntervalSince1970: lastTimestamp)
        let elapsed = Date().timeIntervalSince(lastDate)

        // Only act if at least 24 hours have passed
        guard elapsed >= 86400 else { return }

        // Check whether the system notification is still pending
        UNUserNotificationCenter.current().getPendingNotificationRequests { requests in
            let isPending = requests.contains { $0.identifier == self.reminderID }

            if isPending {
                // The system notification hasn't fired yet (app was likely open).
                // Cancel it and fire immediately.
                UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [self.reminderID])
                self.deliverImmediately()
            } else {
                // The OS likely already delivered it when the app was closed.
                // Nothing extra needed — but we still clear the timestamp so we
                // don't repeatedly check.
                print("[NotificationManager] Reminder was already delivered by OS.")
            }

            // Clear the stored timestamp so we don't re-trigger on the next open
            UserDefaults.standard.removeObject(forKey: self.completionTimestampKey)
        }
    }

    // MARK: - Private

    /// Fires a local notification with a 1-second delay (immediate-ish delivery while app is in foreground).
    private func deliverImmediately() {
        let content = UNMutableNotificationContent()
        content.title = "Mindful Reminder 🌸"
        content.body = "Pause. Breathe. Reset.\nA few mindful minutes can transform your entire day."
        content.sound = .default

        // 1-second delay so foreground delegate can handle it
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: "mindful_immediate", content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("[NotificationManager] Failed to deliver immediate reminder: \(error.localizedDescription)")
            } else {
                print("[NotificationManager] Immediate 24h-overdue reminder delivered.")
            }
        }
    }
}
