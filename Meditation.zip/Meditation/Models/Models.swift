import Foundation

// MARK: - Patient (matches Android Patient.java)
struct Patient: Codable {
    var userId: String
    var age: Int
    var gender: String
    var email: String
    var password: String?
    var profile_image: String?

    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case age, gender, email, password, profile_image
    }
}

// MARK: - LoginRequest
struct LoginRequest: Codable {
    var email: String
    var password: String
}

// MARK: - UserProfileResponse
struct UserProfileResponse: Codable {
    var name: String?
    var age: String?
    var gender: String?
    var email: String?
    var profile_image: String?
}

// MARK: - ScoreRequest
struct ScoreRequest: Codable {
    var email: String
    var score: Float
}

struct ModuleScoreRequest: Codable {
    var email: String
    var module: String
    var score: Float
}

// MARK: - ScoreResponse
struct ScoreResponse: Codable {
    var score: Float
    var scoreType: String?
    var createdAt: String?

    enum CodingKeys: String, CodingKey {
        case score
        case scoreType = "score_type"
        case createdAt = "created_at"
    }
}

// MARK: - AudioResponse (matches Android AudioResponse.java)
struct AudioResponse: Codable, Identifiable {
    var id: String { title + (url ?? "") }
    var title: String
    var description: String?
    var url: String?
    var module: String?
}

// MARK: - MLPredictRequest / Response
struct MLPredictRequest: Codable {
    var maas: Int
    var panas_pos: Int
    var panas_neg: Int
    var dass: Int
    var erq: Int
    var phlms: Int
    
    enum CodingKeys: String, CodingKey {
        case maas
        case panas_pos = "panas_pos"
        case panas_neg = "panas_neg"
        case dass, erq, phlms
    }
}

struct SelectedLabel: Codable {
    var label: String
    var probability: Float
    var level: String
}

struct TimetableItem: Codable, Identifiable {
    var id: String { audio_code + title }
    var audio_code: String
    var module: String
    var title: String
    var description: String
}

struct MLPredictResponse: Codable {
    var probabilities: [String: Float]?
    var selected_labels: [SelectedLabel]?
    var timetable: [TimetableItem]?
    
    enum CodingKeys: String, CodingKey {
        case probabilities
        case selected_labels = "selected_labels"
        case timetable
    }
}

// MARK: - App Specific Models
struct SessionInfo: Codable, Identifiable {
    var id: String { title + audioURL }
    var title: String
    var description: String
    var audioURL: String
}

struct AssessmentStats: Codable {
    var lastScore: Int
    var avgScore: Int
    var totalSessions: Int
}

struct RegisterRequest: Codable {
    var email: String
    var password: String
    var age: Int
    var gender: String
}

// MARK: - Persistent Progress Models
struct ModuleCompletionRecord: Codable, Identifiable {
    var id: String { email + moduleType + completionDate }
    var email: String
    var moduleType: String
    var percentageScore: Float
    var taskScore: Float
    var dailyProgress: Float
    var completionDate: String // DD/MM/YYYY
    var graphData: [Float]? // To store historical data if needed
}

struct SavedProgressResponse: Codable {
    var records: [ModuleCompletionRecord]
}
